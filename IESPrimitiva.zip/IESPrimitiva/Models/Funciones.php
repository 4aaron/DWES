<?php

	# Alta de usuarios

	// Función que permite dar de alta un empleado
	function altaEmpleado($conexion, $dni, $nombre, $apellido, $email) {
		try {
			$stmt = "INSERT INTO empleado VALUES ('$dni', '$nombre', '$apellido', '$email')";
			$conexion -> exec($stmt);
			echo "<div class='h5' align='center'>El empleado $nombre ha sido dado de alta</div>";
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>El empleado $nombre con DNI $dni ya existe<br>" . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite dar de alta un apostante
	function altaApostante($conexion, $dni, $nombre, $apellido, $email) {
		try {
			$stmt = "INSERT INTO apostante VALUES ('$dni', '$nombre', '$apellido', '$email', '0')";
			$conexion -> exec($stmt);
			echo "<div class='h5' align='center'>El apostante $nombre ha sido dado de alta</div>";
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>El apostante $nombre con DNI $dni ya existe<br>" . $e -> getMessage() . "</div>";
		}
	}


	# Validación del inicio de sesión de usuarios

	// Función que permite verificar el login de un empleado
	function loginEmpleado($conexion, $usuario, $password) {
		try {
			$stmt = $conexion -> prepare("SELECT dni, apellido FROM empleado WHERE dni = '$usuario' AND apellido = '$password'");
			$stmt -> execute();
			$loginCorrecto = false;
			$result = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
			foreach ($stmt -> fetchAll() as $row) {
				if ($row["dni"] == $usuario && $row["apellido"] == $password) {
					$loginCorrecto = true;
				}
			}
			return $loginCorrecto;
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";	
		}
	}

	// Función que permite verificar el login de un apostante
	function loginApostante($conexion, $usuario, $password) {
		try {
			$stmt = $conexion -> prepare("SELECT dni, apellido FROM apostante WHERE dni = '$usuario' AND apellido = '$password'");
			$stmt -> execute();
			$loginCorrecto = false;
			$result = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
			foreach ($stmt -> fetchAll() as $row) {
				if ($row["dni"] == $usuario && $row["apellido"] == $password) {
					$loginCorrecto = true;
				}
			}
			return $loginCorrecto;
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}


	# Obtención de los datos de los usuarios

	// Función que permite obtener los datos de un empleado
	function nombreEmpleado($user, $conexion) {
		try {
			$datos = array();
			$stmt = $conexion -> prepare("SELECT nombre, apellido FROM empleado WHERE dni = '$user'");
			$stmt -> execute();
			$result = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
			foreach ($stmt -> fetchAll() as $row) {
				$datos[0] = $row["nombre"];
				$datos[1] = $row["apellido"];
			}
			return $datos;
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite obtener los datos de un aposante
	function nombreApostante($user, $conexion) {
		try {
			$datos = array();
			$stmt = $conexion -> prepare("SELECT nombre, apellido, email, saldo FROM apostante WHERE dni = '$user'");
			$stmt -> execute();
			$result = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
			foreach ($stmt -> fetchAll() as $row) {
				$datos[0] = $row["nombre"];
				$datos[1] = $row["apellido"];
				$datos[2] = $row["saldo"];
				$datos[3] = $row["email"];
			}
			return $datos;
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}


	# Alta de sorteos

	// Función que permite asignar el formato deseado a los sorteos (S001, S002, S003...)
	function formatoSorteo() {
		try {
			$conexion = conexion();
			$stmt = $conexion -> prepare("SELECT max(NSORTEO) AS 'nsorteo' FROM sorteo");
			$stmt -> execute();
			
			foreach ($stmt -> fetchAll() as $row) {
				$codigoSorteo = $row['nsorteo'];
			}
			
			if ($codigoSorteo == null) {
				$codigoSorteoNumerado = "S001";
				return $codigoSorteoNumerado;
			} else {
				$codigoSorteoNumerado = substr($codigoSorteo, -3);
				$codigoSorteoNumerado += 1;
				$codigoSorteoNumerado = "S" . str_pad($codigoSorteoNumerado, 3, "0", STR_PAD_LEFT);
				return $codigoSorteoNumerado;
			}
			
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}
	
	// Función que permite insertar el sorteo en una fecha especifiada por el usuario usando el formato correcto
	function insertSorteo($conexion, $fecha, $user) {
		try {
			$codigoSorteoNumerado = formatoSorteo();
			$stmt = "INSERT INTO sorteo VALUES('$codigoSorteoNumerado', '$fecha', '0', '0', '$user', 'S', '')";
			$conexion -> exec($stmt);
			echo "<div class='h5' align='center'>Se ha dado de alta el sorteo</div>";
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	
	# Realizar Sorteos

	// Función que permite ver los sorteos que están activos en un desplegable. También se utiliza esta función en Realizar Apuesta View.
	function mostrarSorteosActivos($id) {
		try {
			$conexion = conexion();
			$stmt = $conexion->prepare("SELECT NSORTEO FROM sorteo WHERE activo = 'S'");
			$stmt -> execute();
			echo "<select name='idSorteo'>";
			foreach ($stmt -> fetchAll() as $row) {
				echo "<option value='" . $row["NSORTEO"] . "'>" . $row["NSORTEO"] . "</option>";
			}
			echo "</select>";
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función permite almacenar la combinación ganadora en un array
	function generarCombinacion() {
		$combinacionGanadora = array();
		$contador = 0;
		
		while ($contador != 7) {
			$bola = rand(1,49);
			if (!in_array($bola, $combinacionGanadora)) {
				$combinacionGanadora[$contador] = $bola;
				$contador++;
			} else {
				$bola = rand(1,49);
			}
		}

		$reintegro = rand(1,9);
		$combinacionGanadora[7] = $reintegro;
		return $combinacionGanadora;
	}

	// Función que permite añadir a la tabla sorteo la combinación ganadora
	function añadirCombinacion($conexion, $nSorteo, $combinacionGanadora) {
		try {
			$combinacion = "";
			foreach ($combinacionGanadora as $indice => $valor) {
				if ($indice != 8) {
					$numero = strval($valor);
					$combinacion .= $numero . " ";
				}
			}
			$stmt = "UPDATE sorteo SET COMBINACION_GANADORA = '$combinacion' WHERE nSorteo = '$nSorteo'";
			$conexion -> exec($stmt);
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite obtener la recaudación del sorteo
	function recaudacionTotal($conexion, $nSorteo) {
		try {
			$stmt = $conexion -> prepare("SELECT recaudacion FROM sorteo WHERE nsorteo = '$nSorteo'");
			$stmt -> execute();
			$resultado = $stmt -> fetch(PDO::FETCH_NUM);
			return $resultado;			
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite actualizar la recaudación de los premios
	function actualizarPremios($conexion, $nSorteo) {
		try {
			$recaudacion = recaudacionTotal($conexion,$nSorteo);
			$recaudacionPremios = intval($recaudacion[0]/2);
			$stmt = "UPDATE sorteo SET recaudacion_premios = '$recaudacionPremios' WHERE nSorteo = '$nSorteo'";
			$conexion -> exec($stmt);
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite cambiar el estado del sorteo
	function cambiarEstadoSorteo($conexion, $nSorteo) {
		try {
			$stmt = "UPDATE sorteo SET activo='N' WHERE nSorteo = '$nSorteo'";
			$conexion -> exec($stmt);
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que muestra las bolas con la combinación ganadora, el complementario y el reintegro
	function mostrarCombinacionGanadora($combinacionGanadora) {
		echo "<br><div class='h4' align='center'>";
			echo "<span class='bolaGanadora'></span>&nbsp;Combinación&nbsp;";
			echo "<span class='bolaComplementario'></span>&nbsp;Complementario&nbsp;";
			echo "<span class='bolaReintegro'></span>&nbsp;Reintegro";
			echo "<br><br><br>";
			foreach ($combinacionGanadora as $indice => $valor) {
				$bolaFormateada = str_pad($valor, 2, "0", STR_PAD_LEFT);
				if ($indice != 8 && $indice != 7 && $indice != 6) {
					echo "<span class='bolaGanadora'>" . $bolaFormateada . "</span>";
				}
				if ($indice == 6) {
					echo "<span class='bolaComplementario'>" . $bolaFormateada . "</span>";
				}	
				if ($indice == 7) {
					echo "<span class='bolaReintegro'>" . $bolaFormateada . "</span>";
				}
			}
		echo "</div>";
	}

	// Función que permite realizar el sorteo juntando varias funciones
	function realizarSorteo($conexion, $combinacionGanadora) {
		try {
			$nSorteo = $combinacionGanadora[8];
			if ($nSorteo != null){
				añadirCombinacion($conexion, $nSorteo, $combinacionGanadora);
				actualizarPremios($conexion, $nSorteo);
				cambiarEstadoSorteo($conexion, $nSorteo);
				echo "<div class='h5' align='center'><br><br>" . $nSorteo . "&nbsp;realizado correctamente.</div>";
			}
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	# Consulta de Sorteos

	// Función que obtiene todos los sorteos disponibles
	function mostrarTodosSorteos($id) {
		try {
			$conexion = conexion();
			$stmt = $conexion -> prepare("SELECT NSORTEO FROM sorteo");	 
			$stmt -> execute();
			echo "<select name='idSorteo'>";
				foreach ($stmt -> fetchAll() as $row){
					echo '<option value="' . $row["NSORTEO"] . '">' . $row["NSORTEO"] . '</option>';
				}
			echo "</select>";
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite obtener los datos de los sorteos
	function obtenerDatosSorteo($conexion, $sorteo) {
		try {
			$stmt = $conexion -> prepare("SELECT * FROM sorteo WHERE NSORTEO = '$sorteo'");
			$stmt -> execute();
			$resultado = $stmt -> fetch(PDO::FETCH_ASSOC);
			return $resultado;
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite mostrar en una tabla el sorteo seleccionado por el usuario
	function mostrarSorteoSeleccionado($conexion, $datos) {
		echo "<table border='1' width='70%' align='center'><tr>";
			echo "<td class='tituloTabla h5'>Sorteo</td>";
			echo "<td class='tituloTabla h5'>Fecha</td>";
			echo "<td class='tituloTabla h5'>Recaudación</td>";
			echo "<td class='tituloTabla h5'>Recaudación de los Premios</td>";
			echo "<td class='tituloTabla h5'>DNI Empleado</td>";
			echo "<td class='tituloTabla h5'>Activo</td>";
			echo "<td class='tituloTabla h5'>Combinación Ganadora</td>";
			echo "</tr>";
			echo "<tr>";
			foreach($datos as $row) {
				echo "<td class='contenidoTabla h5'>" . $row . "</td>";
			}
		echo "</tr></table>";
	}


	# Realizar Apuesta

	// Función que permite obtener los sorteos activos
	function sorteos($conexion, $dni) {
		try {
			$stmt = $conexion -> prepare("SELECT NSORTEO FROM sorteo WHERE activo = 'S'");	 
			$stmt -> execute();
			$resultado = $stmt -> fetchAll(PDO::FETCH_ASSOC);
			return $resultado;
			} catch(PDOException $e) {
				echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
			}
	}

	// Función que permite obtener el saldo del usuario registrado
	function saldoApostante($conexion, $dni) {
		try {
			$stmt = $conexion -> prepare("SELECT saldo FROM apostante WHERE dni = '$dni'");
			$stmt -> execute();
			$resultado = $stmt -> fetch(PDO::FETCH_ASSOC);
			return $resultado;
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite obtener el id de las apuestas
	function numeroApuesta($conexion) {
		try {
			$stmt = $conexion -> prepare("SELECT max(NAPUESTA) AS codigo FROM apuestas");
			$stmt -> execute();
			
			foreach ($stmt -> fetchAll() as $row) {
				$nApuesta = $row['codigo'];
			}
			
			if ($nApuesta == null) {
				$nApuestaFinal = 1;
				return $nApuestaFinal;
			} else {
				$nApuestaFinal = $nApuesta;
				$nApuestaFinal += 1;
				return $nApuestaFinal;
			}
			
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite insertar la apuesta con los números introducidos por el usuario
	function insertApuesta($conexion, $dni, $sorteo, $fecha, $apuestas) {
		try {
			$nApuesta = numeroApuesta($conexion);
			$stmt = "INSERT INTO apuestas VALUES('$nApuesta', '$dni', '$sorteo', '$fecha', '$apuestas[0]', '$apuestas[1]', '$apuestas[2]', '$apuestas[3]', '$apuestas[4]', '$apuestas[5]', '$apuestas[6]', '$apuestas[7]', null, null)";
			$conexion->exec($stmt);
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}
	
	// Función que obtiene el valor actual de la recaudación del sorteo
	function recaudacionPremios($conexion, $sorteo) {
		try {
			$stmt = $conexion -> prepare("SELECT max(recaudacion) AS recaudacion FROM sorteo WHERE NSORTEO = '$sorteo'");
			$stmt -> execute();
			$resultado = $stmt -> fetch(PDO::FETCH_ASSOC);
			return $resultado;
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite actualizar la recaudación del sorteo
	function updatePremioRecaudacion($conexion, $sorteo) {
		try {
			$recaudacion = recaudacionPremios($conexion,$sorteo);
			$nuevaCantidad = $recaudacion["recaudacion"]+1;
			$stmt = "UPDATE sorteo SET recaudacion = '$nuevaCantidad' WHERE NSORTEO = '$sorteo'";
			$conexion -> exec($stmt);
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}
	
	// Función que permite actualizar el saldo del apostante una vez realizada su apuesta
	function updateSaldo($conexion, $dni) {
		try {
			$saldo = saldoApostante($conexion,$dni);
			$nuevaCantidad = $saldo["saldo"]-1;
			
			if ($saldo["saldo"] != 0) {
				$stmt = "UPDATE apostante SET SALDO = '$nuevaCantidad' WHERE DNI = '$dni'";
				$conexion -> exec($stmt);
			}
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}	
	}
	
	// Función que permite realizar la apuesta juntando varias funciones
	function realizarApuesta($conexion, $dni, $sorteo, $fecha, $apuestas) {
		try {
			if ($apuestas != null) {
				$numerosApuestas = count($apuestas);
				insertApuesta($conexion, $dni, $sorteo, $fecha, $apuestas);
				updatePremioRecaudacion($conexion, $sorteo);
				updateSaldo($conexion, $dni);
			} else {
				echo "No se ha realizado ninguna apuesta en el SORTEO:$sorteo" . "<br>";
			}
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	# Cargar Saldo
	
	// Función que actualiza el saldo introducido por el apostante sumandolo a la cantidad inicial
	function cargarSaldo($conexion, $dni, $amount) {
		try {
			$saldo = saldoApostante($conexion, $dni);
			$saldoCargado = $saldo["saldo"] + ($amount);
			$stmt = "UPDATE apostante SET saldo = '$saldoCargado' WHERE dni = '$dni'";
			$conexion -> exec($stmt);
			echo "<div class='h5' align='center'>Saldo cargado correctamente. Saldo: $saldoCargado €.</div><br>";
		} catch (PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}
	
	
	# Consultar Apuestas

	// Función que obtiene todos los sorteos
	function consultarApuestas($id) {
		try {
			$conexion = conexion();
			$stmt = $conexion -> prepare("SELECT NSORTEO FROM sorteo");	 
			$stmt -> execute();
			$resultado = $stmt -> fetchAll(PDO::FETCH_COLUMN, 0);
			return $resultado;
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite mostrar el sorteo seleccionado en un desplegable
	function mostrarTodasApuestas($id) {
		try {
			$conexion = conexion();
			$stmt = $conexion -> prepare("SELECT NSORTEO FROM sorteo");
			$stmt -> execute();
			echo "<select name='idSorteo'>";
				foreach ($stmt -> fetchAll() as $row) {
					echo '<option value="' . $row["NSORTEO"] . '">' . $row["NSORTEO"] . '</option>';
				}
			echo "</select>";
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite obtener todas las apuestas realizadas por un cliente en un sorteo seleccionado
	function recopilarDatos($conexion, $sorteo, $dni) {
		try {
			$stmt = $conexion -> prepare("SELECT * FROM apuestas WHERE NSORTEO = '$sorteo' AND dni = '$dni'");
			$stmt -> execute();
			$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
			return $resultado;
		} catch(PDOException $e) {
			echo "<div class='h5' align='center'>Error: " . $e -> getMessage() . "</div>";
		}
	}

	// Función que permite mostrar en una tabla las apuestas del sorteo seleccionado por el usuario
	function mostrarApuestasDelSorteoSeleccionado($conexion, $datos) {
		echo "<table border='1' align='center'>";
		echo "<tr>";
		echo "<td class='tituloTabla h5' width='150px'>Nº de Apuesta</td>";
		echo "<td class='tituloTabla h5' width='120px'>DNI</td>";
		echo "<td class='tituloTabla h5' width='150px'>Nº de Sorteo</td>";
		echo "<td class='tituloTabla h5' width='200px'>Fecha</td>";
		echo "<td class='tituloTabla h5' width='60px'>N1</td>";
		echo "<td class='tituloTabla h5' width='60px'>N2</td>";
		echo "<td class='tituloTabla h5' width='60px'>N3</td>";
		echo "<td class='tituloTabla h5' width='60px'>N4</td>";
		echo "<td class='tituloTabla h5' width='60px'>N5</td>";
		echo "<td class='tituloTabla h5' width='60px'>N6</td>";
		echo "<td class='tituloTabla h5' width='170px'>Complementario</td>";
		echo "<td class='tituloTabla h5' width='120px'>Reintegro</td>";
		echo "<td class='tituloTabla h5' width='200px'>Importe del premio</td>";
		echo "<td class='tituloTabla h5' width='200px'>Categoría del premio</td>";
		echo "</tr>";
		foreach ($datos as $row1 => $row2) {
			echo "<tr>";
			foreach ($row2 as $row3 => $row4) {
				echo "<td class='contenidoTabla h5'>" . $row4 . "</td>";
			}
			echo "</tr>";
		}		
		echo "</table>";
	}

?>
