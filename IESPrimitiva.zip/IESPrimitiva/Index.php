<?php

	require_once "./Views/Inicio_View.php";

?>