<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	$datosCliente = nombreApostante($_SESSION["user"], $conexion);
	require_once "../Views/Cargar_Saldo_View.php";
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") { // Si el formulario se envía
		if (isset($_POST["cargar"])) { // Si el botón de Cargar Saldo es pulsado
			$dni = $_SESSION["user"];
			$_SESSION["amount"] = $_POST["amount"];
			if (empty($_SESSION["amount"])) {
				echo "<div class='h5' align='center'>Debe introducir un saldo correcto</div>";
			} else {
				header("Location: ./redsysHMAC256_API_PHP_7.0.0/ejemploGeneraPet.php");
			}
		}
	}
	
?>
