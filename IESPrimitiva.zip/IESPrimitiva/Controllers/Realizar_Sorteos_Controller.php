<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["dni"])) {
		header("Location: ../index.php");
	} else {
		require_once "../Views/Realizar_Sorteos_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$dni = $_SESSION["dni"];
			$sorteo = "";
			// La variable $sorteo almacena el sorteo seleccionado por el usuario.
			// Su valor inicial estará en blanco para validar si hay sorteos disponibles.
			
			if (empty($_POST["idSorteo"])) { // Si no hay sorteos disponibles mostrar un mensaje de error
				echo "<div class='h5' align='center'>No hay sorteos disponibles</div>";
			} else {
				$sorteo = $_POST["idSorteo"];
				unset($_SESSION["numerosPremiados"]); // Vaciamos la sesión que contiene el resultado del sorteo para evitar errores.

				if (isset($_POST["realizar"])) { // Si el botón Realizar Sorteo es pulsado
					$combinacionSorteo = generarCombinacion();
					$_SESSION["numerosPremiados"] = $combinacionSorteo;
					array_push($_SESSION["numerosPremiados"],$sorteo);
					$combinacionGanadora = $_SESSION["numerosPremiados"];
					mostrarCombinacionGanadora($combinacionGanadora);
					realizarSorteo($conexion,$combinacionGanadora,$dni);

					$apuestas=obtenerApuestas($conexion, $sorteo);
					$_SESSION["dniApostante"] = $apuestas[8];
					$dniApostante = $_SESSION["dniApostante"];
					$_SESSION["fecha"] = $apuestas[9];
					$fecha = $_SESSION["fecha"];
					$_SESSION["nApuesta"] = $apuestas[10];
					$minNapuesta = $_SESSION["nApuesta"];
					repartirPremios($conexion, $sorteo, $dniApostante, $minNapuesta, $fecha, $combinacionSorteo);
				}
			}
		}
	}

?>
