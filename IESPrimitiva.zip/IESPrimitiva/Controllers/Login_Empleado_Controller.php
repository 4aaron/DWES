<?php

	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Login_Empleado_View.php";

	if ($_POST) {
		$conexion = conexion();
		$usuario = $_POST["usuario"];
		$password = $_POST["clave"];

		if (empty($usuario) || empty($password)) { // Si el campo usuario o contraseña están en blanco se muestra un error
			echo "<div class='h5' align='center'>El usuario y contraseña deden ser rellenados</div>";
			
			} else if (loginEmpleado($conexion, $usuario, $password)) { // Si se rellenaron los campos correctamente creamos la sesión y redirigimos al controlador
				session_start();
				$_SESSION["user"] = $_POST["usuario"];
				header("Location: ./Welcome_Empleado_Controller.php");
				} else { // Si ambos campos han sido rellenados pero son incorrectos se muestra un error
					echo "<div class='h5' align='center'>El usuario o contraseña introducidos son incorrectos</div>";
		}
	}
	
?>
