<?php

	session_start();
	// Se incluye la librería
	include "apiRedsys.php";
	include_once "../../Databases/Database.php";
	include_once "../../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["amount"])) {
		header("Location: ../../Index.php");
	} else {
		// Se crea Objeto
		$miObj = new RedsysAPI;
		// Valores de entrada que no hemos cmbiado para ningun ejemplo
		$fuc = "999008881";
		$terminal = "1";
		$moneda = "978";
		$trans = "0";
		$url = "";
		
		// Desarrollo
		$urlOK = "http://localhost/Recuperaci%c3%b3n/IESPrimitiva/Controllers/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php";
		$urlKO = "http://localhost/Recuperaci%c3%b3n/IESPrimitiva/Controllers/Welcome_Apostante_Controller.php";
		
		// Producción
		//$urlOK = "http://192.168.206.222/AaronMoreno/IESPrimitiva/Controllers/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php";
		//$urlKO = "http://192.168.206.222/AaronMoreno/IESPrimitiva/Controllers/Welcome_Apostante_Controller.php";
		
		$id = time();
		$amount = $_SESSION["amount"]*100;
		
		// Se Rellenan los campos
		$miObj -> setParameter("DS_MERCHANT_AMOUNT",$amount);
		$miObj -> setParameter("DS_MERCHANT_ORDER",$id);
		$miObj -> setParameter("DS_MERCHANT_MERCHANTCODE",$fuc);
		$miObj -> setParameter("DS_MERCHANT_CURRENCY",$moneda);
		$miObj -> setParameter("DS_MERCHANT_TRANSACTIONTYPE",$trans);
		$miObj -> setParameter("DS_MERCHANT_TERMINAL",$terminal);
		$miObj -> setParameter("DS_MERCHANT_MERCHANTURL",$url);
		$miObj -> setParameter("DS_MERCHANT_URLOK",$urlOK);
		$miObj -> setParameter("DS_MERCHANT_URLKO",$urlKO);

		//Datos de configuración
		$version = "HMAC_SHA256_V1";
		$kc = 'sq7HjrUOBfKmC576ILgskD5srU870gJ7';//Clave recuperada de CANALES
		// Se generan los parámetros de la petición
		$request = "";
		$params = $miObj -> createMerchantParameters();
		$signature = $miObj -> createMerchantSignature($kc);
	}
?>

<html lang="es">
	<head>
	<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta http-equiv="X-UA-Compatible" content="ie=edge">
			<title>Cargar Saldo</title>
			<link rel="stylesheet" href="../../Css/bootstrap.min.css">
	</head>
	<body>
	<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header h1">Cargar Saldo</div>
				<div class="card-body h5">
					<?php echo "Importe total:&nbsp;&nbsp;&nbsp;" . $_SESSION["amount"] . "€"; ?>
					<br><br>
					<form name="frm" action="https://sis-t.redsys.es:25443/sis/realizarPago" method="POST" target="_self">
						<input type="text" hidden name="Ds_SignatureVersion" value="<?php echo $version; ?>"/>
						<input type="text" hidden name="Ds_MerchantParameters" value="<?php echo $params; ?>"/>
						<input type="text" hidden name="Ds_Signature" value="<?php echo $signature; ?>"/>
						<input type="submit" value="Continuar Operación" class="btn btn-warning disabled">
						<input type="button" value="Cancelar Operación" onclick="window.location.href='../Cargar_Saldo_Controller.php'" class="btn btn-warning disabled">
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
