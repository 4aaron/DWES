<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Fin de la operación</title>
		<link rel="stylesheet" href="../../Css/bootstrap.min.css">
	</head>
	<body>
		<br><div class="container" align="center">
			<div class="card border-success mb-3" style="max-width: 30rem;">
				<div class="card-header h1">Cargar Saldo</div>
				<div class="card-header h4">
				<?php
					session_start();
					include "apiRedsys.php";
					include_once "../../Databases/Database.php";
					include_once "../../Models/Funciones.php";
					$conexion = conexion();
					
					if (empty($_SESSION["dni"])) {
						header("Location: ../../Index.php");
					} else {
						// Se crea Objeto
						$miObj = new RedsysAPI;

						if (!empty( $_POST ) ) {//URL DE RESP. ONLINE
							$version = $_POST["Ds_SignatureVersion"];
							$datos = $_POST["Ds_MerchantParameters"];
							$signatureRecibida = $_POST["Ds_Signature"];

							$decodec = $miObj->decodeMerchantParameters($datos);	
							$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
							$firma = $miObj->createMerchantSignatureNotif($kc,$datos);	

							echo PHP_VERSION."<br/>";
							echo $firma."<br/>";
							echo $signatureRecibida."<br/>";
							if ($firma === $signatureRecibida){
								echo "<div class='card-body h5'>FIRMA OK - POST</div>";
								?>
								<div class="form-group">
								<form method="post">
									<?php
										$saldo = cargarSaldo($conexion,$_SESSION["dni"],$_SESSION["amount"]);
										header("Refresh:10; url='../Welcome_Apostante_Controller.php'");
									?>
								</form>
								</div>
								<?php
							} else {
								echo "FIRMA KO";
							}
						} else {
							if (!empty( $_GET ) ) {//URL DE RESP. ONLINE
									
								$version = $_GET["Ds_SignatureVersion"];
								$datos = $_GET["Ds_MerchantParameters"];
								$signatureRecibida = $_GET["Ds_Signature"];
							
								$decodec = $miObj->decodeMerchantParameters($datos);
								$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
								$firma = $miObj->createMerchantSignatureNotif($kc,$datos);
							
								if ($firma === $signatureRecibida){
									echo "<div class='card-body h5'>FIRMA OK - GET</div>";
									?>
									<div class="form-group">
									<form method="get">
										<?php
											$saldo = cargarSaldo($conexion,$_SESSION["dni"],$_SESSION["amount"]);
											header("Refresh:5; url='../Welcome_Apostante_Controller.php'");
										?>
									</form>
									</div>
									<?php
								} else {
									echo "FIRMA KO";
								}
							} else {
								die("No se recibió respuesta");
							}
						}
					}
				?>
				</div>
			</div>
		</div>
	</body> 
</html>
