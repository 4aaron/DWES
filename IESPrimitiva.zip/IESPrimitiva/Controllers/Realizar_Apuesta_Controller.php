<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	$datosCliente = nombreApostante($_SESSION["user"], $conexion);
	require_once "../Views/Realizar_Apuesta_View.php";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$dni = $_SESSION["user"];
		$sorteo = "";
		$fecha = date("Y-m-d H:i:s");
		// La ariable $sorteo almacena el sorteo seleccionado por el usuario.
		// Su valor inicial estará en blanco para validar si hay sorteos disponibles.

		if (empty($_POST["idSorteo"])) { // Si no hay sorteos disponibles mostrar un mensaje de error
			echo "<div class='h5' align='center'>No hay sorteos disponibles</div>";
		} else {
			$sorteo = $_POST["idSorteo"];

			if (isset($_POST["realizar"])) { // Si el botón Realizar Apuesta es pulsado
				// Guardamos los números introducidos por el usuario en variables
				$n1 = $_POST["n1"];
				$n2 = $_POST["n2"];
				$n3 = $_POST["n3"];
				$n4 = $_POST["n4"];
				$n5 = $_POST["n5"];
				$n6 = $_POST["n6"];
				$c = $_POST["c"];
				$r = $_POST["r"];
				// Validamos que los números introducidos por el usuario estén rellenados y no se repitan
				if (empty($n1) || empty($n2) || empty($n3) || empty($n4) || empty($n5) || empty($n6) || empty($c) || empty($r)) {
					echo "<div class='h5' align='center'>Debe rellenar los 6 campos</div>";
					} else if ($n1 == $n2 || $n1 == $n3 || $n1 == $n4 || $n1 == $n5 || $n1 == $n6) {
						echo "<div class='h5' align='center'>No se pueden repetir números</div>";
						} else if ($n2 == $n1 || $n2 == $n3 || $n2 == $n4 || $n2 == $n5 || $n2 == $n6) {
							echo "<div class='h5' align='center'>No se pueden repetir números</div>";
							} else if ($n3 == $n1 || $n3 == $n2 || $n3 == $n4 || $n3 == $n5 || $n3 == $n6) {
								echo "<div class='h5' align='center'>No se pueden repetir números</div>";
								} else if ($n4 == $n1 || $n4 == $n2 || $n4 == $n3 || $n4 == $n5 || $n4 == $n6) {
									echo "<div class='h5' align='center'>No se pueden repetir números</div>";
									} else if ($n5 == $n1 || $n5 == $n2 || $n5 == $n3 || $n5 == $n4 || $n5 == $n6) {
										echo "<div class='h5' align='center'>No se pueden repetir números</div>";
										} else if ($n6 == $n1 || $n6 == $n2 || $n6 == $n3 || $n6 == $n4 || $n6 == $n5) {
											echo "<div class='h5' align='center'>No se pueden repetir números</div>";
				} else {
					if (!isset($_SESSION["$sorteo"])) {
						$_SESSION["apuesta"] = array($n1,$n2,$n3,$n4,$n5,$n6,$c,$r); // Guardamos la apuesta en una variable de sesión llamada apuesta
						$apuestaRealizada = $_SESSION["apuesta"]; // Guardamos la variable de sesión apuestas en una variable con el nombre $apuestaRealizada
						$_SESSION["$sorteo"] = $apuestaRealizada; // Guardamos $apuestaRealizada en la variable de sesión $sorteo
					}

					$sorteos = sorteos($conexion,$dni);
					$saldoApostante = saldoApostante($conexion,$dni);

					if ($saldoApostante["saldo"] >= 1) {
						foreach($sorteos as $indice => $consulta){
							$sorteo=$consulta["NSORTEO"];

								if (isset($_SESSION[$sorteo])) {
									$apuestas = $_SESSION[$sorteo];
									realizarApuesta($conexion, $dni, $sorteo, $fecha, $apuestas);
									echo "<div class='h5' align='center'>Apuesta realizada</div>";
									unset($_SESSION[$sorteo]);
								}
						}
					} else {
						echo "<div class='h5' align='center'>No dispone de saldo suficiente para apostar</div>";
					}
				}
			}
		}
	}

?>
