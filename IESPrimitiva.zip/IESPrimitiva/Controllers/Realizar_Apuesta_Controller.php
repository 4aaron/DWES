<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["dni"])) {
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Realizar_Apuesta_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$dni = $_SESSION["dni"];
			$sorteo = "";
			$fecha = date("Y-m-d H:i:s");
			// La variable $sorteo almacena el sorteo seleccionado por el usuario.
			// Su valor inicial estará en blanco para validar si hay sorteos disponibles.

			if (empty($_POST["idSorteo"])) { // Si no hay sorteos disponibles mostrar un mensaje de error
				echo "<div class='h5' align='center'>No hay sorteos disponibles en los que apostar</div>";
			} else {
				if (isset($_POST["realizar"])) { // Si el botón Realizar Apuesta es pulsado
					// Guardamos los números introducidos por el usuario en variables
					$n1 = $_POST["n1"];
					$n2 = $_POST["n2"];
					$n3 = $_POST["n3"];
					$n4 = $_POST["n4"];
					$n5 = $_POST["n5"];
					$n6 = $_POST["n6"];
					$c = $_POST["c"];
					$r = $_POST["r"];
					// Validamos que los números introducidos por el usuario estén rellenados y no se repitan
					if (empty($n1) || empty($n2) || empty($n3) || empty($n4) || empty($n5) || empty($n6) || empty($c) || empty($r)) {
						echo "<div class='h5' align='center'>Debe rellenar todos los campos</div>";
						} else if ($n1 == $n2 || $n1 == $n3 || $n1 == $n4 || $n1 == $n5 || $n1 == $n6 || $n1 == $c) {
							echo "<div class='h5' align='center'>No se pueden repetir números</div>";
							} else if ($n2 == $n1 || $n2 == $n3 || $n2 == $n4 || $n2 == $n5 || $n2 == $n6 || $n2 == $c) {
								echo "<div class='h5' align='center'>No se pueden repetir números</div>";
								} else if ($n3 == $n1 || $n3 == $n2 || $n3 == $n4 || $n3 == $n5 || $n3 == $n6 || $n3 == $c) {
									echo "<div class='h5' align='center'>No se pueden repetir números</div>";
									} else if ($n4 == $n1 || $n4 == $n2 || $n4 == $n3 || $n4 == $n5 || $n4 == $n6 || $n4 == $c) {
										echo "<div class='h5' align='center'>No se pueden repetir números</div>";
										} else if ($n5 == $n1 || $n5 == $n2 || $n5 == $n3 || $n5 == $n4 || $n5 == $n6 || $n5 == $c) {
											echo "<div class='h5' align='center'>No se pueden repetir números</div>";
											} else if ($n6 == $n1 || $n6 == $n2 || $n6 == $n3 || $n6 == $n4 || $n6 == $n5 || $n6 == $c) {
												echo "<div class='h5' align='center'>No se pueden repetir números</div>";
					} else {
						$sorteo = $_POST["idSorteo"];
						$sorteos = sorteos($conexion, $dni);
						if ($_SESSION["saldo"] >= 1) {
							$apuestas = array($n1, $n2, $n3, $n4, $n5, $n6, $c, $r);
							realizarApuesta($conexion, $dni, $sorteo, $fecha, $apuestas);
							echo "<div class='h5' align='center'>Apuesta realizada</div>";
							header("Refresh:1");
						} else {
							echo "<div class='h5' align='center'>No dispone de saldo suficiente para apostar</div>";
						}

					}
				}
			}
		}
	}

?>
