<?php

	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	session_start();
	$conexion = conexion();
	$datosCliente = nombreEmpleado($_SESSION["user"], $conexion);
	require_once "../Views/Welcome_Empleado_View.php";

?>
