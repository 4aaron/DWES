<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["dni"])) {
		header("Location: ../index.php");
	} else {
		$datosEmpleado = datosEmpleado($_SESSION["dni"], $conexion);
		$_SESSION["nombre"] = $datosEmpleado[0];
		$_SESSION["apellido"] = $datosEmpleado[1];
		require_once "../Views/Welcome_Empleado_View.php";
	}
	
?>
