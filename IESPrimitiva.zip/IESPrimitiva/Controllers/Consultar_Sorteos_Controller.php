<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["dni"])) {
		header("Location: ../index.php");
	} else {
		require_once "../Views/Consultar_Sorteos_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") { // Si el formulario se envía
			$sorteo = "";
			// La variable $sorteo almacena el sorteo seleccionado por el usuario.
			// Su valor inicial estará en blanco para validar si hay sorteos disponibles.

			if (empty($_POST["idSorteo"])) { // Si no hay sorteos disponibles mostrar un mensaje de error
				echo "<div class='h5' align='center'>No hay sorteos disponibles</div>";
			} else {
				$dni = $_SESSION["dni"];
				$sorteo = $_POST["idSorteo"];

				if (isset($_POST["consultar"])) { // Si el botón de consultar es pulsado
					$datos = obtenerDatosSorteo($conexion, $sorteo);
					mostrarSorteoSeleccionado($conexion, $datos);
				}
			}
		}
	}

?>
