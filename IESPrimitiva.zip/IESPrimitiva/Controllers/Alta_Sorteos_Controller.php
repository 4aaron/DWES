<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();
	
	if (empty($_SESSION["dni"])) {
		header("Location: ../Index.php");
	} else {
		$_SESSION["fecha"] = date("Y-m-d h:i:s", time());
		require_once "../Views/Alta_Sorteos_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") { // Si el formulario se envía
			if (isset($_POST["daralta"])) { // Si el botón de Dar de alta sorteos es pulsado
				$dni = $_SESSION["dni"];
				$fecha = $_POST["fecha"];
				if (empty($fecha)) { // Si el campo fecha no es rellenado mostrar un error
					echo "<div class='h5' align='center'>Debe rellenar todos los campos</div>";
				} else {
					if(isset($fecha)){
						insertSorteo($conexion, $fecha, $dni);
					}
				}
			}
		}
	}

?>
