<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();

	if (empty($_SESSION["dni"])) {
		header("Location: ../Index.php");
	} else {
		$datosApostante = datosApostante($_SESSION["dni"], $conexion);
		$_SESSION["nombre"] = $datosApostante[0];
		$_SESSION["apellido"] = $datosApostante[1];
		$_SESSION["saldo"] = $datosApostante[2];
		require_once "../Views/Welcome_Apostante_View.php";
	}

?>
