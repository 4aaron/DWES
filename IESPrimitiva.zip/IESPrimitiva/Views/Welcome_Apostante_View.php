<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Sorteo Primitiva</title>
		<link rel="stylesheet" href="../CSS/bootstrap.min.css">
	</head>
	<body>
		<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header"><img src="../Images/La_Primitiva.png"></div>
			<div class="h4"><br>Bienvenido <?php echo "$datosCliente[0]&nbsp;$datosCliente[1]"; ?>.&nbsp;Seleccione una opción:</div>
				<div class="card-body h5">
					<input type="button" value="Realizar Apuesta" onclick="window.location.href='../Controllers/Realizar_Apuesta_Controller.php'" class="btn btn-warning disabled">
					<input type="button" value="Cargar Saldo" onclick="window.location.href='../Controllers/Cargar_Saldo_Controller.php'" class="btn btn-warning disabled">
					<input type="button" value="Consultar Apuestas" onclick="window.location.href='../Controllers/Consultar_Apuestas_Controller.php'" class="btn btn-warning disabled">
					<br><br><a href="../Controllers/Cerrar_Sesion_Controller.php">Cerrar Sesión</a>
				</div>
			</div>
		</div>
	</body>
</html>
