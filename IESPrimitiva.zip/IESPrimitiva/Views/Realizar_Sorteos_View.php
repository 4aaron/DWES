<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Realizar Sorteo</title>
		<link rel="stylesheet" href="../Css/bootstrap.min.css">
		<style>
			.bolaGanadora { color: white; background-color: #4a844c; padding: 10px; margin: 10px; border-radius: 25px; }
			.bolaComplementario { color: white; background-color: red; padding: 10px; margin: 10px; border-radius: 25px; }
			.bolaReintegro { color: white; background-color: blue; padding: 10px; margin: 10px; border-radius: 25px; }
		</style>
	</head>

	<body>
		<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header h1">Realizar Sorteos</div>
			<div class="h4">
				<br>Bienvenido <?php echo "$datosCliente[0]&nbsp;$datosCliente[1]"; ?>.<br>Seleccione el sorteo a realizar:
			</div>
				<div class="card-body">
					<form method="post" action="Realizar_Sorteos_Controller.php">
						<?php
							echo "<div class='h4'>Sorteos disponibles:&nbsp;";
							echo mostrarSorteosActivos($_SESSION["user"]) . "</div><br>";
						?>
						<div class="form-group">
							<input type="submit" name="realizar" value="Realizar Sorteo" class="btn btn-warning disabled">
							<input type="button" name="volver" value="Volver" onclick="window.location.href='../Controllers/Welcome_Empleado_Controller.php'" class="btn btn-warning disabled">
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
