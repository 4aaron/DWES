<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Consultar Apuestas</title>
		<link rel="stylesheet" href="../Css/bootstrap.min.css">
		<style>
			tr td {	text-align:center; margin:1%; padding:1%; }
			.tituloTabla { background-color: #93C54B; }
			.contenidoTabla { background-color: #f7aa80; }
		</style>
	</head>
	<body>
		<br><div class="container" align="center">
			<div class="card border-success mb-3" style="max-width: 30rem;">
				<div class="card-header h1">Consultar Apuestas</div>
				<div class="card-header h4">
					<?php echo "DNI:&nbsp;" . $_SESSION["dni"] . "&nbsp;&nbsp;-&nbsp;&nbsp;Saldo:&nbsp;" . $_SESSION["saldo"] . "€"; ?>
				</div>
					<div class="card-body h4">
						<form method="post" action="Consultar_Apuestas_Controller.php">
							<?php
								$sorteos=consultarApuestas($_SESSION["dni"]);
								echo "<div class='h4'>Sorteos disponibles:&nbsp;";
								echo mostrarTodasApuestas($sorteos) . "</div><br>";
							?>
							<div class="form-group">
								<input type="submit" name="consultar" value="Consultar Apuestas" class="btn btn-warning disabled">
								<input type="button" name="volver" value="Volver" onclick="window.location.href='../Controllers/Welcome_Apostante_Controller.php'" class="btn btn-warning disabled">
							</div>
						</form>
					</div>
				</div>
			</div>
		</body>
</html>
