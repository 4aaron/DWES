<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Sorteo Primitiva</title>
		<link rel="stylesheet" href="./Css/bootstrap.min.css">
	</head>
	<body>
		<br><div class="container" align="center">
			<div class="card border-success mb-3" style="max-width: 30rem;">
				<div class="card-header"><img src="./Images/La_Primitiva.png"></div>
				<div class="card-header h4">Bienvenido al sorteo de la Primitiva</div>
				<div class="card-body">
					<form method="post">
						<div class="form-group h5">Alta de usuarios<br>
							<input type="button" value="Empleado" onclick="window.location.href='./Controllers/Alta_Empleado_Controller.php'" class="btn btn-warning disabled">
							<input type="button" value="Apostante" onclick="window.location.href='./Controllers/Alta_Apostante_Controller.php'" class="btn btn-warning disabled">
						</div>
						<div class="form-group h5">Inicio de sesión<br>
							<input type="button" value="Empleado" onclick="window.location.href='./Controllers/Login_Empleado_Controller.php'" class="btn btn-warning disabled">
							<input type="button" value="Apostante" onclick="window.location.href='./Controllers/Login_Apostante_Controller.php'" class="btn btn-warning disabled">
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
