<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Cargar Saldo</title>
		<link rel="stylesheet" href="../Css/bootstrap.min.css">
		<style>
			input{ text-align:center; }
		</style>
	</head>
	<body>
		<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header h1">Cargar Saldo</div>
			<div class="card-header h4">
				<?php echo "DNI:&nbsp;" . $_SESSION["dni"] . "&nbsp;&nbsp;-&nbsp;&nbsp;Saldo:&nbsp;" . $_SESSION["saldo"] . "€"; ?>
			</div>
				<div class="card-body h5">
					<form method="post" action="Cargar_Saldo_Controller.php">
						<div class="form-group">Ingresar saldo:<br><br>
							<input type="number" name="amount" min="1" placeholder="Saldo" class="form-control" autofocus>
						</div>
						<div class="form-group">
							<input type="submit" name="cargar" value="Cargar Saldo" class="btn btn-warning disabled">
							<input type="button" name="volver" value="Volver" onclick="window.location.href='../Controllers/Welcome_Apostante_Controller.php'" class="btn btn-warning disabled">
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
