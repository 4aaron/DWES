<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Alta Empleado</title>
		<link rel="stylesheet" href="../Css/bootstrap.min.css">
		<style>
			input{ text-align:center; }
		</style>
	</head>
	<body>
		<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header h1">Alta Empleado</div>
			<div class="card-header h4">Ingrese los datos para registrarse</div>
				<div class="card-body h5">
					<form method="post" action="Alta_Empleado_Controller.php">
						<div class="form-group"><input type="text" name="dni" placeholder="DNI del Empleado" class="form-control" minlength="9" maxlength="9" autofocus></div>
						<div class="form-group"><input type="text" name="nombre" placeholder="Nombre del Empleado" class="form-control"></div>
						<div class="form-group"><input type="text" name="apellido" placeholder="Apellidos del Empleado" class="form-control"></div>
						<div class="form-group"><input type="text" name="email" placeholder="Email del Empleado" class="form-control"></div>
						<div class="form-group">
							<input type="submit" name="daralta" value="Dar de alta" class="btn btn-warning disabled">
							<input type="button" name="volver" value="Volver" onclick="window.location.href='../Index.php'" class="btn btn-warning disabled">
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
