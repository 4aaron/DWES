<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Sorteo Primitiva</title>
		<link rel="stylesheet" href="../Css/bootstrap.min.css">
		<style>
			input{ text-align:center; }
		</style>
	</head>
	<body>
		<br><div class="container" align="center">
		<div class="card border-success mb-3" style="max-width: 30rem;">
			<div class="card-header"><img src="../Images/La_Primitiva.png"></div>
			<div class="card-header h4">Inicio de sesión de empleados</div>
				<div class="card-body h5">
					<form method="post" action="Login_Empleado_Controller.php">
						<div class="form-group"><input type="text" name="usuario" placeholder="Usuario [DNI]" class="form-control" minlength="9" maxlength="9" autofocus></div>
						<div class="form-group"><input type="password" id="entrada" name="clave" placeholder="Contraseña [Apellido]" class="form-control"></div>
						<div class="form-group"><input type="submit" name="iniciarsesion" value="Iniciar Sesión" class="btn btn-warning disabled"></div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
