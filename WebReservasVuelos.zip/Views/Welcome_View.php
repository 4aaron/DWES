<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Bienvenido a Web Reservas Vuelos</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input {text-align: center;}
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-size: 100% 100%; margin:5%;}
		</style>
	</head>

	<body>
		<div class="container" align="center">
			<div class="card" style="max-width: 75rem; background-color: lightblue;">
				<div class="card-body">
					<h3>Bienvenido <?php session_start(); echo $_SESSION["name"]; ?> a Web Reservas Vuelos</h3>
					<br>
					<img src="https://th.bing.com/th/id/R.8dd974be9c3274346c87f1f3c01ca192?rik=1eM0hO%2bWYBLIiQ&riu=http%3a%2f%2fpngimg.com%2fuploads%2fplane%2fplane_PNG5219.png&ehk=4sZD6XOq296zzdWDVn4%2bmjloZTgtt2piyOfyK3JzWfo%3d&risl=&pid=ImgRaw&r=0" alt="avion" width="700" height="300">
					<br><br>
					<input type="button" value="Reservar Vuelos" onclick="window.location.href='../Controllers/Reservar_Vuelos_Controller.php'" class="btn disabled btn-outline-light" style="background-color: red;">
					<input type="button" value="Check In" onclick="window.location.href='../Controllers/Check_In_Controller.php'" class="btn disabled btn-outline-light" style="background-color: red;">
					<input type="button" value="Consultar Vuelos" onclick="window.location.href='../Controllers/Consultar_Vuelos_Controller.php'" class="btn disabled btn-outline-light" style="background-color: red;">
					<br><br><a href="../Controllers/Cerrar_Sesion_Controller.php">Cerrar Sesión</a>
					<br><br>
					<?php /* $vars = get_defined_vars(); print_r($vars); */ ?>
				</div>
			</div>
		</div>
	</body>
</html>
