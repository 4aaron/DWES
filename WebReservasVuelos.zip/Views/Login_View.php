<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Login Web Reserva Vuelos</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input {text-align: center;}
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed;	background-size: cover; background-size: 100% 100%; margin:5%;}
			.mensaje {border: 1px solid white; border-radius: 12px; padding: 10px; color: white; background-color:#e24b50;}
		</style>
	</head>

	<body>
		<div class="container" align="center">
			<div class="card" style="max-width: 30rem; background-color: lightblue;">
				<div class="card-body">
					<h2>Inicio de sesión</h2>
					<br>
					<form method="post">
						<div class="form-group">
						<input type="text" name="email" class="form-control form-control-lg" placeholder="Usuario (Correo)" autofocus>
						</div>
						<div class="form-group">
						<input type="text" name="password" class="form-control form-control-lg" placeholder="Contraseña (Cumpleaños)">
						</div>
						<input type="submit" value="Iniciar Sesión" class="btn disabled btn-outline-light" style="background-color: red;">
					</form>
					<br>
					<h6>¿No está registrado? <a href="./Controllers/Registro_Controller.php">Regístrese</a></h6>
				</div>
			</div>
		</div>
	</body>
</html>
