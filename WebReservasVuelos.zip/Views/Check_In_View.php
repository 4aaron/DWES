<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Check In</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input {text-align: center;}
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-size: 100% 100%; margin:5%;}
			.navbar-text a{color: #e24b50; padding: 2px 15px; border-radius: 50px; /* transition: 0.3s; */font-weight: bold;}
  			.navbar-text a:hover{background-color: #e24b50; color: white;}
		</style>
	</head>

	<body>
		
		<nav class="navbar navbar-expand-sm navbar-text fixed-top"><br>
			<div class="container">
				<a href="../Views/Welcome_View.php" class="navbar-brand">Web Reservas Vuelos</a>
				<button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarCollapse">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a href="../Controllers/Reservar_Vuelos_Controller.php" class="nav-link">Reservar Vuelos</a></li>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<li class="nav-item"><a href="../Controllers/Consultar_Vuelos_Controller.php" class="nav-link">Consultar Vuelos</a></li>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<li class="nav-item"><a href="../Controllers/Cerrar_Sesion_Controller.php" class="nav-link">Cerrar Sesión</a></li>
					</ul>
				</div>
			</div>
		</nav>
		
		<div class="container" align="center">
			<div class="card" style="max-width: 75rem; background-color: lightblue;">
				<div class="card-body">
					<h3>Check In</h3>

					


				</div>
			</div>
		</div>
		<!--
		ENLACES:
		https://github.com/FaztWeb/bootstrap-website-one/blob/master/index.html
		https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css
		https://wallpaperaccess.com/full/896979.jpg
		https://www.w3schools.com/bootstrap4/bootstrap_navbar.asp
		https://signin.rockstargames.com/signin/user-form?cid=socialclub
		-->

	</body>
</html>