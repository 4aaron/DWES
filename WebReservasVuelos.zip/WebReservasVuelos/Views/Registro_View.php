<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Registro Web Reserva Vuelos</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input {text-align: center; height: 40px;}
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-size: 100% 100%; margin:5%;}
			select {text-align: center;}
			.mensaje {border: 1px solid white; border-radius: 12px; padding: 10px; color: white; background-color:#e24b50;}
		</style>
	</head>

	<body>
		<div class="container" align="center">
			<div class="card" style="max-width: 30rem; background-color: lightblue;">
				<div class="card-body">
					<h3>Registrarse</h3>
					<p>Rellene los siguientes campos para registrarse:</p>
					<form method="post">
						<div class="form-group">
						<input type="text" name="name" class="form-control form-control-lg" placeholder="Nombre" autofocus required>
						</div>
						<div class="form-group">
						<input type="date" name="birthdate" class="form-control form-control-lg" required >
						</div>
						<div class="form-group">
							<select name="sex" class="form-control form-control-lg" required>
								<option value="" disabled selected hidden>Seleccione su género</option>
								<option>Hombre</option>
								<option>Mujer</option>
							</select>
						</div>
						<div class="form-group">
						<input type="text" name="street" class="form-control form-control-lg" placeholder="Calle" required>
						</div>
						<div class="form-group">
						<input type="text" name="city" class="form-control form-control-lg" placeholder="Ciudad" required>
						</div>
						<div class="form-group">
						<input type="number" name="zip" class="form-control form-control-lg" placeholder="Zip" min="1000" max="49882" minlength="4" maxlength="5" required>
						</div>
						<div class="form-group">
						<input type="text" name="country" class="form-control form-control-lg" placeholder="País" required>
						</div>
						<div class="form-group">
						<input type="text" name="emailaddress" class="form-control form-control-lg" placeholder="Correo" required>
						</div>
						<div class="form-group">
						<input type="number" name="telephoneno" class="form-control form-control-lg" placeholder="Teléfono" min="600000000" max="999999999" minlength="9" maxlength="9" required>
						</div>
						<input type="submit" value="Registrarse" class="btn disabled btn-outline-light" style="background-color: red;">
						<input type="button" value="Volver" onclick="window.location.href='../Index.php'" class="btn disabled btn-outline-light" style="background-color: red;">
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
