<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Consultar Vuelos</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input {text-align: center;}
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-size: 100% 100%; margin:5%;}
			.navbar-text a{color: #e24b50; padding: 2px 15px; border-radius: 50px; /* transition: 0.3s; */font-weight: bold;}
  			.navbar-text a:hover{background-color: #e24b50; color: white;}
			select {text-align: center;}
			tr td {text-align: center; margin:1%; padding:1%;}
			.tituloTabla {background-color: #e24b50; color: white;}
			.contenidoTabla {background-color: lightblue; color: black;}
			.mensaje {border: 1px solid white; border-radius: 12px; padding: 10px; color: white; background-color:#e24b50;}
		</style>
	</head>

	<body>
		<nav class="navbar navbar-expand-sm navbar-text fixed-top"><br>
			<div class="container">
				<a href="../Views/Welcome_View.php" class="navbar-brand">Web Reservas Vuelos</a>
				<div class="collapse navbar-collapse" id="navbarCollapse">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a href="../Controllers/Reservar_Vuelos_Controller.php" class="nav-link">Reservar Vuelos</a></li>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<li class="nav-item"><a href="../Controllers/Check_In_Controller.php" class="nav-link">Check In</a></li>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<li class="nav-item"><a href="../Controllers/Consultar_Check_In_Controller.php" class="nav-link">Consultar Check In</a></li>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<li class="nav-item"><a href="../Controllers/Cerrar_Sesion_Controller.php" class="nav-link">Cerrar Sesión</a></li>
					</ul>
				</div>
			</div>
		</nav>
		
		<div class="container" align="center">
			<div class="card" style="max-width: 75rem; background-color: lightblue;">
				<div class="card-body">
					<h3>Consultar Vuelos</h3>
					<br>
					<form method="post" action="Consultar_Vuelos_Controller.php">
						<?php desplegableDeTodosLosVuelos($_SESSION["passenger_id"]); ?><br>
						<input type="submit" value="Consultar" class="btn disabled btn-outline-light" style="background-color: red;">
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
