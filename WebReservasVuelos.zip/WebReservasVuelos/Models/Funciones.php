<?php


# Login


# Validar que el Usuario no existe

function validarUsuario($conexion, $emailaddress, $birthdate) {
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll();
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Generar un Id para el nuevo usuario

function idUsuario($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT MAX(passenger_id) AS id FROM passengerdetails");
		$stmt -> execute();
		
		foreach ($stmt -> fetchAll() as $stmt){
			$passenger_id = $stmt["id"];
		}
		
		if ($passenger_id == null) {
			$passenger_id_actualizada = 1;
			return $passenger_id_actualizada;
			} else {
				$passenger_id_actualizada = $passenger_id;
				$passenger_id_actualizada += 1;
				return $passenger_id_actualizada;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Registro del Usuario

function registroUsuario($conexion, $passenger_id, $name, $birthdate, $sex, $street, $city, $zip, $country, $emailaddress, $telephoneno) {
	try {
		$stmt = "INSERT INTO passengerdetails VALUES ('$passenger_id', '$name', '$birthdate', '$sex', '$street', '$city', '$zip', '$country', '$emailaddress', '$telephoneno')";
		$conexion -> exec($stmt);
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario $name ha sido dado de alta</span></div>";
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar el Login del Usuario

function loginUsuario($conexion, $emailaddress, $password) {
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress' AND birthdate = '$password'");
		$stmt -> execute();
		$loginCorrecto = false;
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			if ($row["emailaddress"] == $emailaddress && $row["birthdate"] == $password) {
				$loginCorrecto = true;
			}
		}
		return $loginCorrecto;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener datos del Usuario

function datosUsuario($conexion, $emailaddress) {
	try {
		$datos = array();
		$stmt = $conexion -> prepare("SELECT passenger_id, name, birthdate, sex, street, city, zip, country, telephoneno FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			$datos[0] = $row["passenger_id"];
			$datos[1] = $row["name"];
			$datos[2] = $row["birthdate"];
			$datos[3] = $row["sex"];
			$datos[4] = $row["street"];
			$datos[5] = $row["city"];
			$datos[6] = $row["zip"];
			$datos[7] = $row["country"];
			$datos[8] = $row["telephoneno"];
		}
		return $datos;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Reservar Vuelos


# Obtener los datos de todos los vuelos y mostrarlos en un desplegable


function desplegableConTodosLosVuelos($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT flight.flight_id, origen.name AS 'Origen', destino.name AS 'Destino', airplane.capacity
									FROM airport AS origen, airport AS destino, flight, airplane
									WHERE airplane.airplane_id = flight.airplane_id
									AND flight.from_a = Origen.airport_id
									AND flight.to_a = Destino.airport_id
									AND flight_id NOT IN (SELECT flight.flight_id FROM flight,booking WHERE flight.flight_id = booking.flight_id AND booking.passenger_id='$id' AND booking.seat IS NULL)");
		$stmt -> execute();
		echo "<select name='flight_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach($stmt -> fetchAll() as $stmt2){
				echo '<option value="'.$stmt2["flight_id"].'">'.$stmt2["Origen"]." → ".$stmt2["Destino"]." – ".$stmt2["capacity"].' Plazas</option>';
			}
		echo "</select>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el id del avión del vuelo seleccionado - También se usa en Check_In_Controller.php

function obtenerAirplaneId($conexion, $vuelo) {
	try {
		$stmt = $conexion -> prepare("SELECT airplane_id FROM flight WHERE flight_id = '$vuelo'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener la cantidad de asientos del avión - También se usa en Check_In_Controller.php

function obtenerCapacidadDelAvion($conexion, $idVuelo) {
	try {
		$stmt = $conexion -> prepare("SELECT capacity FROM airplane WHERE airplane_id = '$idVuelo'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener la cantidad de asientos ocupados del avión del vuelo seleccionado - También se usa en Check_In_Controller.php

function asientosOcupados($conexion, $idVuelo) {
	try{
		$stmt = $conexion -> prepare("SELECT count(seat) FROM booking WHERE flight_id = '$idVuelo'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar que el vuelo no se repite

function comprobarVuelos($conexion, $listaVuelos, $vueloReservado) {
	$repetido = false;
	if (in_array($vueloReservado, $listaVuelos)) {
		$repetido = true;
	}
	return $repetido;
}


# 

function obtenerDatosDelVuelo($conexion, $valor) {
	try {
		$stmt = $conexion->prepare("SELECT flight.flightno vuelo, origen.name, destino.name
									FROM airport AS origen, airport AS destino, flight
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight_id = '$valor'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Insertar una fila a la tabla que muestra las reservas pendientes

function mostrarReservas($vuelos) {
	echo "<tr>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[0] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[1] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[2] . "</td>";
	echo "</tr>";
}


# Realizar la reserva del vuelo o vuelos reservados

function reservarVuelos($conexion, $vuelosReservados, $passenger_id) {
	foreach($vuelosReservados as $indice => $valor) {
		$idFlight = $valor;
		$idAirplane = obtenerAirplaneId($conexion, $idFlight);
		$idAirplane = $idAirplane[0];
		$idBooking = maxIdBooking($conexion);
		$capacity = obtenerCapacidadDelAvion($conexion, $idAirplane);
		$capacity = intval($capacity[0]);
		$price = calcularPrecioDelVuelo($conexion, $capacity);
		insertBooking($conexion, $idBooking, $idFlight, $passenger_id, $price);
	}
}


# Obtener el precio del vuelo en función de la cantidad de asientos del avión

function calcularPrecioDelVuelo($conexion, $capacity) {
	$precio = 0;
	if ($capacity <= 100) {
		$precio = 80;
	} else if ($capacity <= 200) {
		$precio = 120;
	} else {
		$precio = 300;
	}
	return $precio;
}


# Obtener el precio total de las reservas

function precioTotalVuelos($conexion, $passenger_id, $vuelosReservados) {
	$totalPrecio = 0;
	foreach($vuelosReservados as $indice => $valor) {
		$idFlight = $valor;
		$precio = precioPorVuelo($conexion, $idFlight, $passenger_id);
		$precio = intval($precio[0]);
		$totalPrecio += intval($precio);
	}
	return $totalPrecio;
}


# Obtener el booking id más alto y generar el siguiente

function maxIdBooking($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT max(booking_id) AS id FROM booking");
		$stmt -> execute();
		
		foreach($stmt -> fetchAll() as $stmt){
			$maxBookingId = $stmt["id"];
		}
		
		if ($maxBookingId == null) {
			$idBooking = 1;
			return $idBooking;
		} else {
			$idBooking = $maxBookingId;
			$idBooking += 1;
			return $idBooking;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Insert de los datos del vuelo en la base de datos

function insertBooking($conexion, $bookingId, $flightId, $passengerId, $price) {
	try {
		$stmt = "INSERT INTO booking VALUES ('$bookingId', '$flightId', null, '$passengerId', '$price')";
		$conexion -> exec($stmt);
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el precio de un vuelo

function precioPorVuelo($conexion, $flightId, $passengerId) {
	try {
		$stmt = $conexion -> prepare("SELECT price FROM booking WHERE passenger_id = '$passengerId' AND flight_id = '$flightId'");	 
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Check In


# Obtener los vuelos reservados que aún no se han realizado y mostrarlos en un desplegable

function desplegableConLosVuelosReservados($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT flight.flight_id, origen.name AS 'Origen', destino.name AS 'Destino'
									FROM flight, airport AS origen, airport AS destino
									WHERE origen.airport_id = flight.from_a 
									AND destino.airport_id = flight.to_a 
									AND flight_id IN (SELECT flight.flight_id FROM flight, booking WHERE flight.flight_id = booking.flight_id AND booking.passenger_id = '$id' AND booking.seat IS NULL)");
		$stmt -> execute();
		echo "<div class='form-group'><select name='flight_id' class='form-control form-control-lg'>";
		echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach($stmt -> fetchAll() as $stmt2) {
				echo '<option value="' . $stmt2["flight_id"] . '">' . $stmt2["Origen"] . " → " . $stmt2["Destino"] . '</option>';
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el id de los vuelos

function obtenerBookingId($conexion, $bookingId, $passengerId) {
	try {
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$passengerId' AND flight_id = '$bookingId' AND seat IS NULL");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Asignar un asiento al usuario

function asignarAsientos($conexion, $bookingId, $passengerId, $asiento) {
	try {
		$stmt = "UPDATE booking SET seat = '$asiento' WHERE booking_id = '$bookingId' AND passenger_id = '$passengerId'";
		$conexion -> exec($stmt);
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar que el usuario no tiene ningún asiento asignado

function validarAsiento($conexion, $passengerId, $idVuelo, $asiento) {
	try {
		$stmt = $conexion -> prepare("SELECT seat from booking where passenger_id = '$passengerId' and flight_id = '$idVuelo' and seat = '$asiento'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_ASSOC);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Generar un asiento aleatorio

function asientos($conexion, $booking_id) {
	$airplaneId = obtenerAirplaneId($conexion, $booking_id);
	$airplaneId = $airplaneId[0];
	$capacidad = obtenerCapacidadDelAvion($conexion, $airplaneId);
	$capacidad = intval($capacidad[0]);
	$asientosFila = 6;
	$aux = $capacidad % $asientosFila;
	if ($aux != 0) { // Si hay asientos libres
		$fila = $capacidad / $asientosFila;
		$fila = round($fila, 0, PHP_ROUND_HALF_UP);
		$totalDeFilas = $fila + 1;
		$filaAsignada = rand(1, $fila);
		if ($filaAsignada == strlen($totalDeFilas)) {
			$letras = 65 + $aux - 1;
			$letra = chr(rand(65, $letras));
			$asiento = $filaAsignada . $letra;
			return $asiento;
		} else if ($filaAsignada != strlen($totalDeFilas)) {
			$letras = 65 + $asientosFila - 1;
			$letra = chr(rand(65, $letras));
			$asiento = $filaAsignada . $letra;
			return $asiento;
		}
	} else if ($aux == 0) { // Si no hay asientos libres
		$fila = $capacidad / $asientosFila;
		$fila = round($fila, 0, PHP_ROUND_HALF_UP);
		$filaAsignada = rand(1, $fila); 
		$letras = 65 + $asientosFila - 1;
		$letra = chr(rand(65, $letras - 1));
		$asiento = $filaAsignada . $letra;
		return $asiento;
	}
}


# Consultar Vuelos


# Obtener el id de todos los vuelos que el usuario ha reservado

function desplegableDeTodosLosVuelos($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$id'");
		$stmt -> execute();
		echo "<div class='form-group'><select name='booking_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach ($stmt -> fetchAll() as $stmt2) {
				echo "<option>" . $stmt2["booking_id"] . "</option>";
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener los datos de todos los vuelos reservados por el usuario

function datosDeTodosLosVuelos($conexion, $booking_id, $passenger_id) {
	try {
		$stmt = $conexion->prepare("SELECT booking.seat, flight.flightno, origen.name, destino.name, flight.departure, flight.arrival, booking.price
									FROM flight, airport AS origen, airport AS destino, booking, passengerdetails
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight.flight_id = booking.flight_id AND booking.passenger_id=passengerdetails.passenger_id AND booking_id='$booking_id' AND passengerdetails.passenger_id='$passenger_id'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Mostrar en una tabla los datos del vuelo seleccionado por el usuario

function tablaConElVueloSeleccionado($conexion, $datos) {
	echo "<br><table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='150px'>Asiento</td>";
			echo "<td class='tituloTabla h5' width='150px'>Vuelo</td>";
			echo "<td class='tituloTabla h5' width='150px'>Origen</td>";
			echo "<td class='tituloTabla h5' width='150px'>Destino</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Salida</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Llegada</td>";
			echo "<td class='tituloTabla h5' width='150px'>Precio (€)</td>";
		echo "</tr>";
		foreach($datos as $row1 => $row2) {
			echo "<tr>";
			foreach($row2 as $row3 => $row4) {
				echo "<td class='contenidoTabla h5'>" . $row4 . "</td>";
			}
			echo "</tr>";
		}
	echo "</table>";
}


# Consultar Check In


# Obtener el id de todos los vuelos realizados que el usuario habia reservado

function desplegableDeVuelosRealizados($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$id' AND seat IS NOT NULL");
		$stmt -> execute();
		echo "<div class='form-group'><select name='booking_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach ($stmt -> fetchAll() as $stmt2) {
				echo "<option>" . $stmt2["booking_id"] . "</option>";
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


?>
