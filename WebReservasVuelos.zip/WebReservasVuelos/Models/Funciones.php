<?php


# Login


# Validar que el Usuario no existe

function validarUsuario($conexion, $emailaddress, $birthdate) {
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll();
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Generar un Id para el nuevo usuario

function idUsuario($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT MAX(passenger_id) AS id FROM passengerdetails");
		$stmt -> execute();
		
		foreach ($stmt -> fetchAll() as $stmt){
			$passenger_id = $stmt["id"];
		}
		
		if ($passenger_id == null) {
			$passenger_id_actualizada = 1;
			return $passenger_id_actualizada;
			} else {
				$passenger_id_actualizada = $passenger_id;
				$passenger_id_actualizada += 1;
				return $passenger_id_actualizada;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Registro del Usuario

function registroUsuario($conexion, $passenger_id, $name, $birthdate, $sex, $street, $city, $zip, $country, $emailaddress, $telephoneno) {
	try {
		$stmt = "INSERT INTO passengerdetails VALUES ('$passenger_id', '$name', '$birthdate', '$sex', '$street', '$city', '$zip', '$country', '$emailaddress', '$telephoneno')";
		$conexion -> exec($stmt);
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario $name ha sido dado de alta</span></div>";
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar el Login del Usuario

function loginUsuario($conexion, $emailaddress, $password) {
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress' AND birthdate = '$password'");
		$stmt -> execute();
		$loginCorrecto = false;
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			if ($row["emailaddress"] == $emailaddress && $row["birthdate"] == $password) {
				$loginCorrecto = true;
			}
		}
		return $loginCorrecto;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener datos del Usuario

function datosUsuario($conexion, $emailaddress) {
	try {
		$datos = array();
		$stmt = $conexion -> prepare("SELECT passenger_id, name, birthdate, sex, street, city, zip, country, telephoneno FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			$datos[0] = $row["passenger_id"];
			$datos[1] = $row["name"];
			$datos[2] = $row["birthdate"];
			$datos[3] = $row["sex"];
			$datos[4] = $row["street"];
			$datos[5] = $row["city"];
			$datos[6] = $row["zip"];
			$datos[7] = $row["country"];
			$datos[8] = $row["telephoneno"];
		}
		return $datos;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Reservar Vuelos


# Obtener los datos de todos los vuelos y mostrarlos en un desplegable

function desplegableConTodosLosVuelos($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT flight.flight_id, origen.name AS 'Origen', destino.name AS 'Destino', airplane.capacity
									FROM airport AS origen, airport AS destino, flight, airplane
									WHERE airplane.airplane_id = flight.airplane_id
									AND flight.from_a = Origen.airport_id
									AND flight.to_a = Destino.airport_id
									AND flight_id NOT IN (SELECT flight.flight_id FROM flight,booking WHERE flight.flight_id = booking.flight_id AND booking.passenger_id='$id' AND booking.seat IS NULL)");
		$stmt -> execute();
		echo "<select name='flight_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach($stmt -> fetchAll() as $stmt2){
				echo '<option value="'.$stmt2["flight_id"].'">'.$stmt2["Origen"]." → ".$stmt2["Destino"]." – ".$stmt2["capacity"].' Plazas</option>';
			}
		echo "</select>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el id del avión del vuelo seleccionado - También se usa en Check_In_Controller.php

function obtenerAirplaneId($conexion, $vuelo) {
	try {
		$stmt = $conexion -> prepare("SELECT airplane_id FROM flight WHERE flight_id = '$vuelo'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el booking id más alto y generar el siguiente

function maxBookingId($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT max(booking_id) AS id FROM booking");
		$stmt -> execute();
		
		foreach($stmt -> fetchAll() as $stmt){
			$maxBookingId = $stmt["id"];
		}
		
		if ($maxBookingId == null) {
			$idBooking = 1;
			return $idBooking;
		} else {
			$idBooking = $maxBookingId;
			$idBooking += 1;
			return $idBooking;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener la cantidad de asientos del avión - También se usa en Check_In_Controller.php

function obtenerCapacidadDelAvion($conexion, $airplaneId) {
	try {
		$stmt = $conexion -> prepare("SELECT capacity FROM airplane WHERE airplane_id = '$airplaneId'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el precio del vuelo en función de la cantidad de asientos del avión

function calcularPrecioDelVuelo($conexion, $capacity) {
	$precio = 0;
	if ($capacity <= 100) {
		$precio = 80;
	} else if ($capacity <= 200) {
		$precio = 120;
	} else {
		$precio = 300;
	}
	return $precio;
}


# Obtener el precio de un vuelo

function precioPorVuelo($conexion, $flightId, $passengerId) {
	try {
		$stmt = $conexion -> prepare("SELECT price FROM booking WHERE passenger_id = '$passengerId' AND flight_id = '$flightId'");	 
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Obtener el precio total de las reservas

function calcularPrecioTotalDeLosVuelos($conexion, $passengerId, $reservas) {
	$precioTotal = 0;
	foreach($reservas as $row => $row2) {
		$flightId = $row2;
		$precio = precioPorVuelo($conexion, $flightId, $passengerId);
		$precio = intval($precio[0]);
		$precioTotal += intval($precio);
	}
	return $precioTotal;
}


# Insert de los datos del vuelo en la base de datos

function insertarBooking($conexion, $bookingId, $flightId, $passengerId, $price) {
	try {
		$stmt = "INSERT INTO booking VALUES ('$bookingId', '$flightId', null, '$passengerId', '$price')";
		$conexion -> exec($stmt);
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener la cantidad de asientos ocupados del avión del vuelo seleccionado - También se usa en Check_In_Controller.php

function asientosOcupados($conexion, $flightId) {
	try{
		$stmt = $conexion -> prepare("SELECT count(seat) FROM booking WHERE flight_id = '$flightId'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar que el vuelo no se repite

function comprobarRepeticionDeLosVuelos($conexion, $vuelos, $reservas) {
	$repetido = false;
	if (in_array($reservas, $vuelos)) {
		$repetido = true;
	}
	return $repetido;
}


# Obtener los datos del vuelo seleccionado

function obtenerDatosDelVuelo($conexion, $flightId) {
	try {
		$stmt = $conexion->prepare("SELECT flight.flightno, origen.name, destino.name
									FROM airport AS origen, airport AS destino, flight
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight_id = '$flightId'");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Insertar una fila a la tabla que muestra las reservas pendientes

function mostrarTablaConLasReservasPendientes($reserva) {
	echo "<tr>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $reserva[0] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $reserva[1] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $reserva[2] . "</td>";
	echo "</tr>";
}


# Realizar la reserva del vuelo o vuelos reservados

function realizarReserva($conexion, $reservas, $passengerId) {
	foreach($reservas as $indice => $valor) {
		$flightId = $valor;
		$airplaneId = obtenerAirplaneId($conexion, $flightId);
		$airplaneId = $airplaneId[0];
		$bookingId = maxBookingId($conexion);
		$capacity = obtenerCapacidadDelAvion($conexion, $airplaneId);
		$capacity = intval($capacity[0]);
		$price = calcularPrecioDelVuelo($conexion, $capacity);
		insertarBooking($conexion, $bookingId, $flightId, $passengerId, $price);
	}
}


# Check In


# Obtener los vuelos reservados que aún no se han realizado y mostrarlos en un desplegable

function desplegableConLosVuelosReservados($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT flight.flight_id, origen.name AS 'Origen', destino.name AS 'Destino'
									FROM flight, airport AS origen, airport AS destino
									WHERE origen.airport_id = flight.from_a 
									AND destino.airport_id = flight.to_a 
									AND flight_id IN (SELECT flight.flight_id FROM flight, booking WHERE flight.flight_id = booking.flight_id AND booking.passenger_id = '$id' AND booking.seat IS NULL)");
		$stmt -> execute();
		echo "<div class='form-group'><select name='flight_id' class='form-control form-control-lg'>";
		echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach($stmt -> fetchAll() as $stmt2) {
				echo '<option value="' . $stmt2["flight_id"] . '">' . $stmt2["Origen"] . " → " . $stmt2["Destino"] . '</option>';
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el id de los vuelos

function obtenerBookingId($conexion, $bookingId, $passengerId) {
	try {
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$passengerId' AND flight_id = '$bookingId' AND seat IS NULL");
		$stmt -> execute();
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Generar un asiento aleatorio

function generarAsientoAleatorio($conexion, $bookingId) {
	$airplaneId = obtenerAirplaneId($conexion, $bookingId);
	$airplaneId = $airplaneId[0];
	$capacidad = obtenerCapacidadDelAvion($conexion, $airplaneId);
	$capacidad = intval($capacidad[0]);
	$asientosFila = 6;
	$numeroDeAsientos = $capacidad % $asientosFila;
	if ($numeroDeAsientos != 0) { // Si hay asientos libres
		$fila = $capacidad / $asientosFila;
		$fila = round($fila, 0, PHP_ROUND_HALF_UP);
		$totalDeFilas = $fila + 1;
		$filaAsignada = rand(1, $fila);
		if ($filaAsignada == strlen($totalDeFilas)) {
			$letras = 65 + $numeroDeAsientos - 1;
			$letra = chr(rand(65, $letras));
			$asiento = $filaAsignada . $letra;
			return $asiento;
		} else if ($filaAsignada != strlen($totalDeFilas)) {
			$letras = 65 + $asientosFila - 1;
			$letra = chr(rand(65, $letras));
			$asiento = $filaAsignada . $letra;
			return $asiento;
		}
	} else if ($numeroDeAsientos == 0) { // Si no hay asientos libres
		$fila = $capacidad / $asientosFila;
		$fila = round($fila, 0, PHP_ROUND_HALF_UP);
		$filaAsignada = rand(1, $fila); 
		$letras = 65 + $asientosFila - 1;
		$letra = chr(rand(65, $letras - 1));
		$asiento = $filaAsignada . $letra;
		return $asiento;
	}
}


# Asignar un asiento al usuario

function asignarAsientos($conexion, $bookingId, $passengerId, $asiento) {
	try {
		$stmt = "UPDATE booking SET seat = '$asiento' WHERE booking_id = '$bookingId' AND passenger_id = '$passengerId'";
		$conexion -> exec($stmt);
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Consultar Vuelos


# Obtener el id de todos los vuelos que el usuario ha reservado

function desplegableDeTodosLosVuelos($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$id'");
		$stmt -> execute();
		echo "<div class='form-group'><select name='booking_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach ($stmt -> fetchAll() as $stmt2) {
				echo "<option>" . $stmt2["booking_id"] . "</option>";
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener los datos de todos los vuelos reservados por el usuario

function datosDeTodosLosVuelos($conexion, $booking_id, $passenger_id) {
	try {
		$stmt = $conexion->prepare("SELECT booking.seat, flight.flightno, origen.name, destino.name, flight.departure, flight.arrival, booking.price
									FROM flight, airport AS origen, airport AS destino, booking, passengerdetails
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight.flight_id = booking.flight_id AND booking.passenger_id=passengerdetails.passenger_id AND booking_id='$booking_id' AND passengerdetails.passenger_id='$passenger_id'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Mostrar en una tabla los datos del vuelo seleccionado por el usuario

function tablaConElVueloSeleccionado($conexion, $datos) {
	echo "<br><table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='150px'>Asiento</td>";
			echo "<td class='tituloTabla h5' width='150px'>Vuelo</td>";
			echo "<td class='tituloTabla h5' width='150px'>Origen</td>";
			echo "<td class='tituloTabla h5' width='150px'>Destino</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Salida</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Llegada</td>";
			echo "<td class='tituloTabla h5' width='150px'>Precio (€)</td>";
		echo "</tr>";
		foreach($datos as $row1 => $row2) {
			echo "<tr>";
			foreach($row2 as $row3 => $row4) {
				echo "<td class='contenidoTabla h5'>" . $row4 . "</td>";
			}
			echo "</tr>";
		}
	echo "</table>";
}


# Consultar Check In


# Obtener el id de todos los vuelos realizados que el usuario habia reservado

function desplegableDeVuelosRealizados($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$id' AND seat IS NOT NULL");
		$stmt -> execute();
		echo "<div class='form-group'><select name='booking_id' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach ($stmt -> fetchAll() as $stmt2) {
				echo "<option>" . $stmt2["booking_id"] . "</option>";
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


?>
