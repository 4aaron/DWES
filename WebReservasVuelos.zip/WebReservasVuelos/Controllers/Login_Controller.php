<?php

	require_once "./Databases/Database.php";
	require_once "./Models/Funciones.php";
	require_once "./Views/Login_View.php";

	if ($_POST) {
		$conexion = conexion();
		if (empty($_POST["email"]) || empty($_POST["password"])) { // Si el campo usuario o contraseña están en blanco se muestra un error
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario y contraseña deden ser rellenados</span></div>";
			
			} else if (loginUsuario($conexion, $_POST["email"], $_POST["password"])) { // Si se rellenaron los campos correctamente creamos la sesión y redirigimos al controlador
				session_start();
				$_SESSION["email"] = $_POST["email"];
				$datosUsuario = datosUsuario($conexion, $_SESSION["email"]); // Obtenemos los datos del usuario
				$_SESSION["passenger_id"] = $datosUsuario[0];
				$_SESSION["name"] = $datosUsuario[1];
				$_SESSION["birthdate"] = $datosUsuario[2];
				$_SESSION["sex"] = $datosUsuario[3];
				$_SESSION["street"] = $datosUsuario[4];
				$_SESSION["city"] = $datosUsuario[5];
				$_SESSION["zip"] = $datosUsuario[6];
				$_SESSION["country"] = $datosUsuario[7];
				$_SESSION["telephoneno"] = $datosUsuario[8];
				header("Location: ./Views/Welcome_View.php");
				
				} else { // Si ambos campos han sido rellenados pero son incorrectos se muestra un error
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario o contraseña introducidos son incorrectos</span></div>";
		}
	}

?>
