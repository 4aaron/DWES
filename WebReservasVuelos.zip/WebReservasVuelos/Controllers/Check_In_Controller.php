<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();

	if (empty($_SESSION["passenger_id"])) { // Validamos que hay un usuario registrado y en caso contrario redirección a la pantalla de login
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Check_In_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {	
			$fecha = date("Y-m-d H:i:s");
			$passenger_id = $_SESSION["passenger_id"];
			if (isset($_POST["flight_id"])) {
				$airplaneId = obtenerAirplaneId($conexion, $_POST["flight_id"]);
				$airplaneId = $airplaneId[0];
				$asientosAvion = obtenerCapacidadDelAvion($conexion, $airplaneId);
				$asientosAvion = intval($asientosAvion[0]);
				$asientosOcupados = asientosOcupados($conexion, $_POST["flight_id"]);
				$asientosOcupados = intval($asientosOcupados[0]);
				if ($asientosAvion != $asientosOcupados) { // Validamos que hay asientos disponibles
					$cont = 0;
					$cont = asientosOcupados($conexion, $_POST["flight_id"]);
					$cont = intval($cont[0]);
					$asiento = generarAsientoAleatorio($conexion, $_POST["flight_id"]);
					$bookingId = obtenerBookingId($conexion, $_POST["flight_id"], $passenger_id);
					if ($bookingId != null) {
						$bookingId = $bookingId[0];
						asignarAsientos($conexion, $bookingId, $passenger_id, $asiento);
						echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Se ha realizado el Check In correctamente</span></div>";
					}
				} else {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El vuelo seleccionado está completo</span></div>";
				}
			} else {
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ningún vuelo</span></div>";
			}
		}
	}

?>
