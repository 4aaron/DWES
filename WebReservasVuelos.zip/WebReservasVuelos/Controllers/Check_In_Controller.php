<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Check_In_View.php";
	$conexion = conexion();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {	
		$fecha = date("Y-m-d H:i:s");
		$passenger_id = $_SESSION["passenger_id"];
		if (isset($_POST["flight_id"])) {
			$airplaneId = obtenerAirplaneId($conexion, $_POST["flight_id"]);
			$airplaneId = $airplaneId[0];
			$capacidad = obtenerCapacidadDelAvion($conexion, $airplaneId);
			$capacidad = intval($capacidad[0]);
			$cont = 0;
			$cont = asientosOcupados($conexion, $_POST["flight_id"]);
			$cont = intval($cont[0]);
			$asiento = asientos($conexion, $_POST["flight_id"]);
			$valido = validarAsiento($conexion, $passenger_id, $_POST["flight_id"], $asiento);
			$bookingId = obtenerBookingId($conexion, $_POST["flight_id"], $passenger_id);
			if ($bookingId != null) {
				$bookingId = $bookingId[0];
				asignarAsientos($conexion, $bookingId, $passenger_id, $asiento);
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Se ha realizado el Check In correctamente</span></div>";
			}
		} else {
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ningún vuelo</span></div>";
		}
	}

?>
