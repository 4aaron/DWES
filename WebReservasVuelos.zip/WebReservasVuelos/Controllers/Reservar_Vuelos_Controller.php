<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Reservar_Vuelos_View.php";
	$conexion = conexion();
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$idUsuario = $_SESSION["passenger_id"];
		if (empty($_POST["flight_id"]) && !isset($_POST["Confirmar"]) && !isset($_POST["Borrar"])) { // Validamos que se ha seleccionado un vuelo del desplegable antes de pulsar el botón de reservar
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Seleccione un vuelo para poder realizar su reserva</span></div>";
		} else {
			if (isset($_POST["Reservar"])) { // Si se pulsa el botón de reservar vuelo
				$airplaneId = obtenerAirplaneId($conexion, $_POST["flight_id"]);
				$airplaneId = $airplaneId[0];
				$asientosAvion = obtenerCapacidadDelAvion($conexion, $airplaneId);
				$asientosAvion = intval($asientosAvion[0]);
				$asientosOcupados = asientosOcupados($conexion, $_POST["flight_id"]);
				$asientosOcupados = intval($asientosOcupados[0]);
				if ($asientosAvion != $asientosOcupados) { // Validamos que hay asientos disponibles
					echo "<br><table align='center'>";
					echo "<tr>";
						echo "<td class='tituloTabla h5' width='150px'>Vuelo</td>";
						echo "<td class='tituloTabla h5' width='150px'>Origen</td>";
						echo "<td class='tituloTabla h5' width='150px'>Destino</td>";
					echo "</tr>";
					if (!isset($_SESSION["VuelosReservados"])) { // Si no hay reservas previas
						$vueloReservado = array(intval($_POST["flight_id"]));
						$_SESSION["VuelosReservados"] = $vueloReservado;
						$vuelos = $_SESSION["VuelosReservados"];
						$vuelo = obtenerDatosDelVuelo($conexion, $vueloReservado[0]);
						mostrarReservas($vuelo);
					} else { // En caso de que haya reservas previas
						$vueloReservado = intval($_POST["flight_id"]);
						$listaVuelos = $_SESSION["VuelosReservados"];
						$repetido = comprobarVuelos($conexion,$listaVuelos, $vueloReservado);
						if (!$repetido) { // Validamos que no se repitan vuelos
							array_push($_SESSION["VuelosReservados"], $vueloReservado);
							$vuelos = $_SESSION["VuelosReservados"];
							foreach ($vuelos as $indice => $valor) {
								$vuelo = obtenerDatosDelVuelo($conexion,$valor);
								mostrarReservas($vuelo);
							}
							echo "</table>";
						} else { // Si se repiten reservas se muestra una alerta con el error y recarga la página
							echo "<script> alert('No puede repetir vuelos'); window.location = './Reservar_Vuelos_Controller.php'; </script>";
							unset($_SESSION["VuelosReservados"]);
						}
					}
				} else {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El vuelo seleccionado está completo</span></div>";
				}
			}
			if (isset($_POST["Confirmar"])) { // Si se pulsa el botón para confirmar la reserva de los vuelos pendientes
				if (empty($_SESSION["VuelosReservados"])) {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No hay reservas pendientes</span></div>";
				} else {
					$vuelosReservados = $_SESSION["VuelosReservados"];
					$passenger_id = $_SESSION['passenger_id'];
					reservarVuelos($conexion, $vuelosReservados, $passenger_id);
					$precio = precioTotalVuelos($conexion, $passenger_id, $vuelosReservados);
					$_SESSION["amount"] = $precio;
					unset($_SESSION["VuelosReservados"]);
					header("Location: ./redsysHMAC256_API_PHP_7.0.0/ejemploGeneraPet.php");
				}
			}
		}
		if (isset($_POST["Borrar"])) { // Si se pulsa el botón para borrar las reservas pendientes
			unset($_SESSION["VuelosReservados"]);
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Las reservas sin confirmar se han borrado correctamente</span></div>";
		}
	}

?>