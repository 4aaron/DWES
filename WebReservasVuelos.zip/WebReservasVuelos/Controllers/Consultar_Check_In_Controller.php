<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	$conexion = conexion();

	if (empty($_SESSION["passenger_id"])) { // Validamos que hay un usuario registrado y en caso contrario redirección a la pantalla de login
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Consultar_Check_In_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$passenger_id = $_SESSION["passenger_id"];
			if (isset($_POST["booking_id"])) {
				$datos = datosDeTodosLosVuelos($conexion, $_POST["booking_id"], $passenger_id);
				tablaConElVueloSeleccionado($conexion, $datos);
			} else {
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ningún vuelo</span></div>";
			}
		}
	}

?>
