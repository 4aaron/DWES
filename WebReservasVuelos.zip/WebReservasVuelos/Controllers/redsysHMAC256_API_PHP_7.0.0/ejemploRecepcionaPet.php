<html>
	<head>
		<meta charset="UTF-8">
		<title>Fin de la operación</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			body {background-image: url("https://wallpaperaccess.com/full/896979.jpg"); background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-size: 100% 100%; margin:5%;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div class="card" style="max-width: 75rem; background-color: lightblue;">
				<div class="card-body">
					<h3>Pago efectuado correctamente</h3>
						<?php
							session_start();
							include "apiRedsys.php";
							include_once "../../Databases/Database.php";
							include_once "../../Models/Funciones.php";
							$conexion = conexion();
							
							if (empty($_SESSION["passenger_id"])) {
								header("Location: ../../Index.php");
							} else {
								// Se crea Objeto
								$miObj = new RedsysAPI;

								if (!empty( $_POST ) ) {//URL DE RESP. ONLINE
									$version = $_POST["Ds_SignatureVersion"];
									$datos = $_POST["Ds_MerchantParameters"];
									$signatureRecibida = $_POST["Ds_Signature"];

									$decodec = $miObj->decodeMerchantParameters($datos);	
									$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
									$firma = $miObj->createMerchantSignatureNotif($kc,$datos);	

									echo PHP_VERSION."<br/>";
									echo $firma."<br/>";
									echo $signatureRecibida."<br/>";
									if ($firma === $signatureRecibida){
										echo "<br><div class='card-body h5'>FIRMA OK - POST</div>";
										echo "<div class='card-body h5'>En breve será redirido";
										?>
										<div class="form-group">
											<form method="post">
												<?php
													header("Refresh:5; url='../../Views/Welcome_View.php'");
												?>
											</form>
										</div>
										<?php
									} else {
										echo "FIRMA KO";
									}
								} else {
									if (!empty( $_GET ) ) {//URL DE RESP. ONLINE
											
										$version = $_GET["Ds_SignatureVersion"];
										$datos = $_GET["Ds_MerchantParameters"];
										$signatureRecibida = $_GET["Ds_Signature"];
									
										$decodec = $miObj->decodeMerchantParameters($datos);
										$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
										$firma = $miObj->createMerchantSignatureNotif($kc,$datos);
									
										if ($firma === $signatureRecibida){
											echo "<br><div class='card-body h5'>FIRMA OK - GET</div>";
											echo "<div class='card-body h5'>En breve será redirido";
											?>
											<div class="form-group">
												<form method="get">
													<?php
														header("Refresh:5; url='../../Views/Welcome_View.php'");
													?>
												</form>
											</div>
											<?php
										} else {
											echo "FIRMA KO";
										}
									} else {
										die("No se recibió respuesta");
									}
								}
							}
						?>
				</div>
			</div>
		</div>
	</body> 
</html>
