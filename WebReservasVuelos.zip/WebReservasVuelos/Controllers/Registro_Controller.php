<?php

	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Registro_View.php";

	$conexion = conexion();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$name = $_POST["name"];
		$birthdate = $_POST["birthdate"];
		$sex = $_POST["sex"];
		$street = $_POST["street"];
		$city = $_POST["city"];
		$zip = $_POST["zip"];
		$country = $_POST["country"];
		$emailaddress = $_POST["emailaddress"];
		$telephoneno = $_POST["telephoneno"];
		if ($sex == "Hombre") {
			$sex = "m";
			} else if ($sex == "Mujer") {
				$sex = "w";
		}
		$usuarioValido = validarUsuario($conexion, $emailaddress, $birthdate);
		if ($usuarioValido == null) {
			$id = idUsuario($conexion);
			registroUsuario($conexion, $id, $name, $birthdate, $sex, $street, $city, $zip, $country, $emailaddress, $telephoneno);
		} else {
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario $emailaddress ya existe</span></div>";
		}
	}

?>
