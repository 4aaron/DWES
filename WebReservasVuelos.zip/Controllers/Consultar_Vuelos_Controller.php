<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Consultar_Vuelos_View.php";
	$conexion = conexion();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$idUsuario = $_SESSION["passenger_id"];
		if (isset($_POST["idVuelo"])) {
			$datos = consultarVuelos($conexion, $_POST["idVuelo"], $idUsuario);
			mostrarVueloSeleccionado($conexion, $datos);
		} else if (empty($_POST["idVuelo"])) {
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No hay vuelos disponibles</span></div>";
		} else {
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ningún vuelo</span></div>";
		}
	}

?>
