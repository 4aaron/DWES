<?php

	session_start();
	require_once "../Databases/Database.php";
	require_once "../Models/Funciones.php";
	require_once "../Views/Check_In_View.php";
	$conexion = conexion();

?>