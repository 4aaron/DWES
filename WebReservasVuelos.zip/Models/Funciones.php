<?php


# Validar que el Usuario no existe

function validarUsuario($conexion, $emailaddress, $birthdate){
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll();
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Generar un Id para el nuevo usuario

function idUsuario($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT MAX(passenger_id) AS id FROM passengerdetails");
		$stmt -> execute();
		
		foreach ($stmt -> fetchAll() as $stmt){
			$passenger_id = $stmt["id"];
		}
		
		if ($passenger_id == null) {
			$passenger_id_actualizada = 1;
			return $passenger_id_actualizada;
			} else {
				$passenger_id_actualizada = $passenger_id;
				$passenger_id_actualizada += 1;
				return $passenger_id_actualizada;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Registro del Usuario

function registroUsuario($conexion, $passenger_id, $name, $birthdate, $sex, $street, $city, $zip, $country, $emailaddress, $telephoneno) {
	try {
		$stmt = "INSERT INTO passengerdetails VALUES ('$passenger_id', '$name', '$birthdate', '$sex', '$street', '$city', '$zip', '$country', '$emailaddress', '$telephoneno')";
		$conexion -> exec($stmt);
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario $name ha sido dado de alta</span></div>";
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Validar el Login del Usuario

function loginUsuario($conexion, $emailaddress, $password) {
	try {
		$stmt = $conexion -> prepare("SELECT emailaddress, birthdate FROM passengerdetails WHERE emailaddress = '$emailaddress' AND birthdate = '$password'");
		$stmt -> execute();
		$loginCorrecto = false;
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			if ($row["emailaddress"] == $emailaddress && $row["birthdate"] == $password) {
				$loginCorrecto = true;
			}
		}
		return $loginCorrecto;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener datos del Usuario

function datosUsuario($conexion, $emailaddress) {
	try {
		$datos = array();
		$stmt = $conexion -> prepare("SELECT passenger_id, name, birthdate, sex, street, city, zip, country, telephoneno FROM passengerdetails WHERE emailaddress = '$emailaddress'");
		$stmt -> execute();
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			$datos[0] = $row["passenger_id"];
			$datos[1] = $row["name"];
			$datos[2] = $row["birthdate"];
			$datos[3] = $row["sex"];
			$datos[4] = $row["street"];
			$datos[5] = $row["city"];
			$datos[6] = $row["zip"];
			$datos[7] = $row["country"];
			$datos[8] = $row["telephoneno"];
		}
		return $datos;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

# Reservar Vuelos

function desplegableVuelos($id){
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT flight.flight_id, flight.flightno AS Vuelo, origen.name AS Origen, destino.name AS Destino, airplane.capacity AS Capacidad
									FROM flight,airport AS origen, airport AS destino, airplane
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight.flight_id = airplane.airplane_id
									AND flight_id NOT IN (SELECT flight.flight_id FROM flight,booking WHERE flight.flight_id = booking.flight_id AND booking.passenger_id='$id' AND booking.seat IS NULL)");
		$stmt -> execute();
		echo "<select name='idVuelo' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach($stmt -> fetchAll() as $stmt2){
				echo '<option value="'.$stmt2["flight_id"].'">'.$stmt2["Origen"]." → ".$stmt2["Destino"]." – ".$stmt2["Capacidad"].' Plazas</option>';
			}
		echo "</select>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function idAvion($conexion, $vuelo){
	try {
		$stmt = $conexion -> prepare("SELECT airplane_id FROM flight WHERE flight_id = '$vuelo'");
		$stmt -> execute();
		
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function asientosAvion($conexion, $idVuelo){
	try {
		$stmt = $conexion -> prepare("SELECT capacity FROM airplane WHERE airplane_id = '$idVuelo'");
		$stmt -> execute();
		
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function asientosOcupados($conexion, $idVuelo){
	try{
		$stmt = $conexion -> prepare("SELECT count(seat) FROM booking WHERE flight_id = '$idVuelo'");
		$stmt -> execute();
		
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function comprobarVuelos($conexion, $listaVuelos, $vueloReservado){
	$repetido = false;
	if (in_array($vueloReservado,$listaVuelos)) {
		$repetido = true;
	}
	return $repetido;
}

function datosVuelo($conexion, $valor) {
	try {
		$stmt = $conexion->prepare("SELECT flight.flightno vuelo, origen.name, destino.name
									FROM airport AS origen, airport AS destino, flight
									WHERE origen.airport_id = flight.from_a AND destino.airport_id = flight.to_a AND flight_id = '$valor'");
		$stmt -> execute();
		
		$resultado = $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}

function mostrarReservas($vuelos){
	echo "<tr>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[0] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[1] . "</td>";
		echo "<td class='contenidoTabla h5' width='150px'>" . $vuelos[2] . "</td>";
	echo "</tr>";
}

function reservarVuelos($conexion, $vuelosReservados, $passenger_id) {
	foreach($vuelosReservados as $indice => $valor){
		$idFlight = $valor;
		$idAirplane = idAvion($conexion, $idFlight);
		$idAirplane = $idAirplane[0];
		$idBooking = maxIdBooking($conexion);
		$seat = null;
		$capacity = asientosAvion($conexion, $idAirplane);
		$capacity = intval($capacity[0]);
		$price = precioVuelo($conexion, $capacity);
		insertBooking($conexion, $idBooking, $idFlight, $seat, $passenger_id, $price);
	}
}

function precioVuelo($conexion, $capacity) {
	$precio = 0;
	if ($capacity <= 100) {
		$precio = 80;
	} else if ($capacity <= 200) {
		$precio = 120;
	} else {
		$precio = 300;
	}
	return $precio;
}

function precioTotalVuelos($conexion, $passenger_id, $vuelosReservados) {
	$totalPrecio = 0;
	foreach($vuelosReservados as $indice => $valor){
		$idFlight = $valor;
		$precio = precioPorVuelo($conexion, $idFlight, $passenger_id);
		$precio = intval($precio[0]);
		$totalPrecio += intval($precio);
	}
	return $totalPrecio;
}

function maxIdBooking($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT max(booking_id) as codigo FROM booking");
		$stmt -> execute();
		
		foreach($stmt -> fetchAll() as $stmt){
			$maxBookingId = $stmt["codigo"];
		}
		
		if ($maxBookingId == null) {
			$idBooking = 1;
			return $idBooking;
		} else {
			$idBooking = $maxBookingId;
			$idBooking += 1;
			return $idBooking;
		}
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function insertBooking($conexion, $idBooking, $idFlight, $seat, $passenger_id, $price) {
	try {
		$stmt = "INSERT INTO booking VALUES ('$idBooking','$idFlight',null,'$passenger_id','$price')";
		$conexion -> exec($stmt);
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function precioPorVuelo($conexion, $idFlight, $passenger_id) {
	try {
		$stmt = $conexion -> prepare("SELECT price FROM booking WHERE passenger_id='$passenger_id' AND flight_id='$idFlight'");	 
		$stmt -> execute();
		$resultado= $stmt -> fetch(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}

function vueloFromTo($conexion, $idVuelo){
	try {
		$stmt = $conexion -> prepare("SELECT f.flightno vuelo, a1.name origen, a2.name destino FROM flight f,airport a1, airport a2 WHERE a1.airport_id=f.from_a AND a2.airport_id=f.to_a AND flight_id ='$idVuelo'");	 
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

# Check In



# Consultar Vuelos

function vuelos($id) {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT booking_id FROM booking WHERE passenger_id = '$id'");
		$stmt -> execute();
		echo "<div class='form-group'><select name='idVuelo' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione un vuelo</option>";
			foreach ($stmt -> fetchAll() as $stmt2) {
				echo "<option>" . $stmt2["booking_id"] . "</option>";
			}
		echo "</select></div>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function consultarVuelos($conexion, $idVuelo, $idUsuario) {
	try {
		$stmt = $conexion->prepare("SELECT booking.seat, flight.flightno, origen.name, destino.name, flight.departure, flight.arrival, booking.price
									FROM flight, airport AS origen, airport AS destino, booking, passengerdetails
									WHERE origen.airport_id=flight.from_a AND destino.airport_id=flight.to_a AND flight.flight_id=booking.flight_id AND booking.passenger_id=passengerdetails.passenger_id AND booking_id='$idVuelo' AND passengerdetails.passenger_id='$idUsuario'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}

function mostrarVueloSeleccionado($conexion,$datos) {
	echo "<br><table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='150px'>Asiento</td>";
			echo "<td class='tituloTabla h5' width='150px'>Vuelo</td>";
			echo "<td class='tituloTabla h5' width='150px'>Origen</td>";
			echo "<td class='tituloTabla h5' width='150px'>Destino</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Salida</td>";
			echo "<td class='tituloTabla h5' width='180px'>Fecha de Llegada</td>";
			echo "<td class='tituloTabla h5' width='150px'>Precio (€)</td>";
		echo "</tr>";
		foreach($datos as $indice => $consulta){
			echo "<tr>";
			foreach($consulta as $indice2 => $datos){
				echo "<td class='contenidoTabla h5'>" . $datos . "</td>";
			}
			echo "</tr>";
		}
	echo "</table>";
}
?>