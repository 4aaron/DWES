<?php

	session_start();
	require_once "../Models/Database_Model.php";
	require_once "../Models/Consultar_Facturas_Model.php";
	require_once "../Views/Consultar_Facturas_View.php";
	$conexion = conexion();

	if (empty($_SESSION["customerId"])) {
		header("Location: ../../Index.php");
	} else {
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$customerId = $_SESSION["customerId"];
			if (isset($_POST["factura"])) {
				$datos = datosFacturas($conexion, $_POST["factura"], $customerId);
				tablaCanciones($conexion, $datos);
			} else {
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ninguna factura</span></div>";
			}
		}
	}

?>
