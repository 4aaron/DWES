<html>
	<head>
		<meta charset="UTF-8">
		<title>Fin de la operación</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input{text-align: center;}
			select{text-align: center;}
			body {margin-top: 5%; background: linear-gradient(rgba(22,22,22,0.989), rgba(22,22,22,0.95), rgba(22,22,22,0.989)), fixed; background-size: cover; font-family: Sans-Serif;}
			.center {display: block; margin-left: auto; margin-right: auto; margin-top: 3%; margin-bottom: 3%; width: 40%;}
			tr td {text-align: center; margin:1%; padding:1%;}
			.tituloTabla {background-color: #1ed760; color: black;}
			.contenidoTabla {background-color: white; color: black;}
			.mensaje {border: 1px solid black; border-radius: 5px; padding: 10px; color: black; background-color: red;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div style="max-width: 60rem; background-color: rgba(0,0,0,0.001);">
				<header>
					<img src="https://cdn2.downdetector.com/static/uploads/logo/Spotify_Logo_RGB_Green.png" alt="Spotify" class="center">
				</header>
				<div class="card-body">
					<h1 style="color: white;">Pago efectuado correctamente</h1>
						<?php
							session_start();
							include "apiRedsys.php";
							include_once "../../Models/Database_Model.php";
							include_once "../../Models/Descargar_Canciones_Model.php";
							$conexion = conexion();
							
							if (empty($_SESSION["customerId"])) {
								header("Location: ../../Index.php");
							} else {
								// Se crea Objeto
								$miObj = new RedsysAPI;

								if (!empty( $_POST ) ) {//URL DE RESP. ONLINE
									$version = $_POST["Ds_SignatureVersion"];
									$datos = $_POST["Ds_MerchantParameters"];
									$signatureRecibida = $_POST["Ds_Signature"];

									$decodec = $miObj->decodeMerchantParameters($datos);	
									$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
									$firma = $miObj->createMerchantSignatureNotif($kc,$datos);	

									echo PHP_VERSION."<br/>";
									echo $firma."<br/>";
									echo $signatureRecibida."<br/>";
									if ($firma === $signatureRecibida){
										echo "<br><h4 style='color: white;'>FIRMA OK - POST<br></h4>";
										echo "<h4 style='color: white;'>En breve será redirigido</h4>";
										?>
										<div class="form-group">
											<form method="post">
												<?php
													$invoiceId = maxInvoiceId($conexion);
													$invoiceDate = date("Y-m-d");
													insertarInvoice($conexion, $invoiceId, $_SESSION["customerId"], $invoiceDate, $_SESSION["amount"]);
													$canciones = $_SESSION["idCancionesAgregadas"];
													foreach($canciones as $trackId) {
														$invoiceLineId = maxInvoiceLineId($conexion, $invoiceId);
														insertarInvoiceLineId($conexion, $invoiceLineId, $invoiceId, $trackId, $_SESSION["unitPrice"], $_SESSION["quantity"]);
													}
													unset($_SESSION["cancionesAgregadas"]);
													unset($_SESSION["idCancionesAgregadas"]);
													unset($_SESSION["amount"]);
													unset($_SESSION["quantity"]);
													header("Refresh:5; url='../../Views/Welcome_View.php'");
												?>
											</form>
										</div>
										<?php
									} else {
										echo "FIRMA KO";
									}
								} else {
									if (!empty( $_GET ) ) {//URL DE RESP. ONLINE
											
										$version = $_GET["Ds_SignatureVersion"];
										$datos = $_GET["Ds_MerchantParameters"];
										$signatureRecibida = $_GET["Ds_Signature"];
									
										$decodec = $miObj->decodeMerchantParameters($datos);
										$kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7"; //Clave recuperada de CANALES
										$firma = $miObj->createMerchantSignatureNotif($kc,$datos);
									
										if ($firma === $signatureRecibida){
											echo "<br><h4 style='color: white;'>FIRMA OK - GET</h4><br>";
											echo "<h4 style='color: white;'>En breve será redirigido</h4>";
											?>
											<div class="form-group">
												<form method="get">
													<?php
														$invoiceId = maxInvoiceId($conexion);
														$invoiceDate = date("Y-m-d");
														insertarInvoice($conexion, $invoiceId, $_SESSION["customerId"], $invoiceDate, $_SESSION["amount"]);
														$canciones = $_SESSION["idCancionesAgregadas"];
														foreach($canciones as $trackId) {
															$invoiceLineId = maxInvoiceLineId($conexion, $invoiceId);
															insertarInvoiceLineId($conexion, $invoiceLineId, $invoiceId, $trackId, $_SESSION["unitPrice"], $_SESSION["quantity"]);
														}
														unset($_SESSION["cancionesAgregadas"]);
														unset($_SESSION["idCancionesAgregadas"]);
														unset($_SESSION["amount"]);
														unset($_SESSION["quantity"]);
														header("Refresh:5; url='../../Views/Welcome_View.php'");
													?>
												</form>
											</div>
											<?php
										} else {
											echo "FIRMA KO";
										}
									} else {
										die("No se recibió respuesta");
									}
								}
							}
						?>
				</div>
			</div>
		</div>
	</body> 
</html>
