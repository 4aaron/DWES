<?php

	session_start();
	require_once "../Models/Database_Model.php";
	require_once "../Models/Descargar_Canciones_Model.php";
	require_once "../Views/Descargar_Canciones_View.php";
	$conexion = conexion();

	if (empty($_SESSION["customerId"])) {
		header("Location: ../../Index.php");
	} else {
		if ($_SERVER["REQUEST_METHOD"] == "POST") {	
			$cancionSeleccionada = "";
			$customerId = $_SESSION["customerId"];

			if (isset($_POST["Agregar"])) {
				if (empty($_POST["cancion"])) {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ninguna canción</span></div>";
				} else {
					$cancionSeleccionada = $_POST["cancion"];
					if (!isset($_SESSION["cancionesAgregadas"])) { // Si no hay canciones añadidas previamente
						$_SESSION["idCancionesAgregadas"] = array($cancionSeleccionada);
						$datosCancion = datosCancion($conexion, $cancionSeleccionada);
						$_SESSION["cancionesAgregadas"] = array($datosCancion);
						mostrarCanciones($_SESSION["cancionesAgregadas"]);
						$_SESSION["quantity"] = 1;
						$_SESSION["unitPrice"] = $datosCancion[1];
						$_SESSION["amount"] = $datosCancion[1];
					} else { // Si ya hay canciones añadidas
						array_push($_SESSION["idCancionesAgregadas"], $cancionSeleccionada);
						$datosCancion = datosCancion($conexion, $cancionSeleccionada);
						array_push($_SESSION["cancionesAgregadas"], $datosCancion);
						mostrarCanciones($_SESSION["cancionesAgregadas"]);
						$_SESSION["amount"] = $_SESSION["amount"] + $datosCancion[1];
					}
				}
			}

			if (isset($_POST["Descargar"])) {
				if (empty($_SESSION["cancionesAgregadas"])) {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Es necesario agregar canciones antes de descargarlas</span></div>";
				} else {
					header("Location: ./redsysHMAC256_API_PHP_7.0.0/ejemploGeneraPet.php");
				}
			}
			if (isset($_POST["Borrar"])) {
				unset($_SESSION["cancionesAgregadas"]);
				unset($_SESSION["idCancionesAgregadas"]);
				unset($_SESSION["amount"]);
				unset($_SESSION["quantity"]);
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Las canciones se eliminaron correctamente</span></div>";
			}
			
		}
	}

?>
