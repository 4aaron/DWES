<?php


# Obtener las facturas del usuario registrado entre las fechas introducidas

function lineasFacturas($conexion, $customerId, $fechaInicio, $fechaFin) {
	try {
		$stmt = $conexion->prepare("SELECT invoiceId, invoiceDate, Total
									FROM invoice
									WHERE customerid = '$customerId' AND invoicedate
									BETWEEN '$fechaInicio' AND '$fechaFin'
									ORDER BY Total DESC");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Mostrar una tabla con los datos de las facturas realizadas entre las fechas introducidas

function tablaFacturas($conexion, $datos) {
	echo "<br><table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='150px'>Factura</td>";
			echo "<td class='tituloTabla h5' width='150px'>Fecha</td>";
			echo "<td class='tituloTabla h5' width='150px'>Total (€)</td>";
		echo "</tr>";
		foreach($datos as $row1 => $row2) {
			echo "<tr>";
			foreach($row2 as $row3 => $row4) {
				echo "<td class='contenidoTabla h5'>" . $row4 . "</td>";
			}
			echo "</tr>";
		}
	echo "</table>";
}


?>
