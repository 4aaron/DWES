<?php


# Verificar el inicio de sesión del usuario

function loginUsuario($conexion, $email, $password) {
	try {
		$stmt = $conexion -> prepare("SELECT email, lastname FROM customer WHERE email = '$email' AND lastname = '$password'");
		$stmt -> execute();
		$loginCorrecto = false;
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			if ($row["email"] == $email && $row["lastname"] == $password) {
				$loginCorrecto = true;
			}
		}
		return $loginCorrecto;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener los datos del usuario

function datosUsuario($conexion, $email) {
	try {
		$datos = array();
		$stmt = $conexion -> prepare("SELECT customerId, firstName, lastName, company, address, city, state, country, postalCode, phone, fax, email FROM customer WHERE email = '$email'");
		$stmt -> execute();
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			$datos[0] = $row["customerId"];
			$datos[1] = $row["firstName"];
			$datos[2] = $row["lastName"];
			$datos[3] = $row["company"];
			$datos[4] = $row["address"];
			$datos[5] = $row["city"];
			$datos[6] = $row["state"];
			$datos[7] = $row["country"];
			$datos[8] = $row["postalCode"];
			$datos[9] = $row["phone"];
			$datos[10] = $row["fax"];
			$datos[11] = $row["email"];
		}
		return $datos;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


?>
