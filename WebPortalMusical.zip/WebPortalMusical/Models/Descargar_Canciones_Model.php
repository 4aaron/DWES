<?php


# Desplegable con las canciones disponibles

function desplegableCanciones() {
	try {
		$conexion = conexion();
		$stmt = $conexion -> prepare("SELECT TrackId, Name, Composer FROM track");
		$stmt -> execute();
		echo "<select name='cancion' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione las canciones que quiere descargar</option>";
			foreach($stmt -> fetchAll() as $stmt2){
				echo '<option value="' . $stmt2["TrackId"] . '">' . $stmt2["Name"] . " - " . $stmt2["Composer"] . '</option>';
			}
		echo "</select>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtención del nombre y precio de la canción que ha sido añadida

function datosCancion($conexion, $trackId) {
	try {
		$datos = array();
		$stmt = $conexion -> prepare("SELECT Name, UnitPrice FROM track WHERE TrackId = '$trackId'");
		$stmt -> execute();
		$resultado = $stmt -> setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt -> fetchAll() as $row) {
			$datos[0] = $row["Name"];
			$datos[1] = $row["UnitPrice"];
		}
		return $datos;
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}	
}


# Mostrar las canciones añadidas en una tabla

function mostrarCanciones($canciones) {
	echo "<table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='200px'>Título de la Canción</b></td>";
			echo "<td class='tituloTabla h5' width='200px'>Precio</td>";
		echo"</tr>";
			foreach ($canciones as $row => $row2) {
				echo "<tr>";
				echo "<td class='contenidoTabla h5' width='500px'>" . $row2[0] . "</td>";
				echo "<td class='contenidoTabla h5' width='200px'>" . $row2[1] . "&nbsp;€</td>";
			}
		echo "</tr>";
	echo "</table><br>";
}


# Obtener el último id de las facturas

function maxInvoiceId($conexion) {
	try {
		$stmt = $conexion -> prepare("SELECT max(InvoiceId) AS invoiceId FROM invoice");
		$stmt -> execute();	
		foreach($stmt -> fetchAll() as $stmt) {
			$invoiceId = $stmt["invoiceId"];
		}	
		if ($invoiceId == null) {
			$nuevoId = 1;
			return $nuevoId;
		} else {
			$nuevoId = $invoiceId;
			$nuevoId += 1;
			return $nuevoId;
		}	
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Insertar la factura en la base de datos

function insertarInvoice($conexion, $invoiceId, $customerId, $invoiceDate, $total, $total2, $moneda) {
	try {  
		$conexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conexion -> beginTransaction();
		$conexion -> exec("INSERT INTO invoice (InvoiceId, CustomerId, InvoiceDate, Total, Total2 , Moneda) VALUES ('$invoiceId', '$customerId', '$invoiceDate', '$total', '$total2', '$moneda')");
		$conexion -> commit();
	} catch (Exception $e) {
		$conexion -> rollBack();
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener el último id de la línea de facturas

function maxInvoiceLineId($conexion, $invoiceId) {
	try {
		$stmt = $conexion -> prepare("SELECT max(InvoiceLineId) AS invoiceLineId FROM invoiceline WHERE invoiceId = '$invoiceId'");
		$stmt -> execute();	
		foreach($stmt -> fetchAll() as $stmt) {
			$invoiceLineId = $stmt["invoiceLineId"];
		}	
		if ($invoiceLineId == null) {
			$nuevoId = 1;
			return $nuevoId;
		} else {
			$nuevoId = $invoiceLineId;
			$nuevoId += 1;
			return $nuevoId;
		}	
	} catch (PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Insertar la línea de facturas en la base de datos

function insertarInvoiceLineId($conexion, $invoiceLineId, $invoiceId, $trackId, $unitPrice, $quantity) {
	try {  
		$conexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conexion -> beginTransaction();
		$conexion -> exec("INSERT INTO invoiceline (InvoiceLineId, InvoiceId, TrackId, UnitPrice, Quantity) VALUES ('$invoiceLineId', '$invoiceId', '$trackId', '$unitPrice', '$quantity')");
		$conexion -> commit();
	} catch (Exception $e) {
		$conexion -> rollBack();
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


?>
