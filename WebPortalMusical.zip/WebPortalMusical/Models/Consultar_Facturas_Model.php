<?php


# Mostrar un desplegable con las facturas disponibles

function desplegableCanciones($customerId) {
	try {
		$conexion = conexion();
		$stmt = $conexion->prepare("SELECT InvoiceId FROM invoice WHERE CustomerId = '$customerId'");
		$stmt -> execute();
		echo "<select name='factura' class='form-control form-control-lg'>";
			echo "<option value='' disabled selected hidden>Seleccione una factura</option>";
			foreach($stmt -> fetchAll() as $stmt2){
				echo '<option value="' . $stmt2["InvoiceId"] . '">' . $stmt2["InvoiceId"] . '</option>';
			}
		echo "</select>";
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Obtener los datos de las facturas del usuario registrado

function datosFacturas($conexion, $factura, $customerId) {
	try {
		$stmt = $conexion->prepare("SELECT InvoiceLineId, Name, Composer
									FROM invoice, invoiceline, track
									WHERE invoice.InvoiceId = invoiceline.InvoiceId
									AND invoiceline.TrackId = track.TrackId
									AND customerid = '$customerId'
									AND invoice.InvoiceId = '$factura'");
		$stmt -> execute();
		$resultado = $stmt -> fetchAll(PDO::FETCH_NUM);
		return $resultado;	
	} catch(PDOException $e) {
		echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Error: " . $e -> getMessage() . "</span></div>";
	}
}


# Mostrar una tabla con los datos de la factura seleccionada

function tablaCanciones($conexion, $datos) {
	echo "<table align='center'>";
		echo "<tr>";
			echo "<td class='tituloTabla h5' width='200px'>Línea</td>";
			echo "<td class='tituloTabla h5' width='500px'>Canción</td>";
			echo "<td class='tituloTabla h5' width='200px'>Compositor</td>";
		echo "</tr>";
		foreach($datos as $row1 => $row2) {
			echo "<tr>";
			foreach($row2 as $row3 => $row4) {
				echo "<td class='contenidoTabla h5'>" . $row4 . "</td>";
			}
			echo "</tr>";
		}
	echo "</table><br>";
}


?>
