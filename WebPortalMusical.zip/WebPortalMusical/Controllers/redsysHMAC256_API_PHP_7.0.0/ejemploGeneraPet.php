<?php

	session_start();
	// Se incluye la librería
	include "apiRedsys.php";
	include_once "../../Models/Database_Model.php";
	include_once "../../Models/Descargar_Canciones_Model.php";
	$conexion = conexion();
	
	if (empty($_SESSION["amount"])) { // Verificamos que hay un pedido válido
		header("Location: ../../Index.php");
	} else {
		// Se crea Objeto
		$miObj = new RedsysAPI;
		// Valores de entrada que no hemos cmbiado para ningun ejemplo
		$fuc = "999008881";
		$terminal = "1";
		$moneda = $_SESSION["moneda"];
		$trans = "0";
		$url = "";
		
		// Desarrollo
		//$urlOK = "http://localhost/Recuperaci%c3%b3n/WebPortalMusical/Controllers/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php";
		//$urlKO = "http://localhost/Recuperaci%c3%b3n/WebPortalMusical/Views/Welcome_View.php";
		
		// Producción
		$urlOK = "http://192.168.206.222/REC/AaronMoreno/WebPortalMusical/Controllers/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php";
		$urlKO = "http://192.168.206.222/REC/AaronMoreno/WebPortalMusical/Views/Welcome_View.php";
		
		$id = time();
		$amount = $_SESSION["amount"] * 100;
		
		// Se Rellenan los campos
		$miObj -> setParameter("DS_MERCHANT_AMOUNT",$amount);
		$miObj -> setParameter("DS_MERCHANT_ORDER",$id);
		$miObj -> setParameter("DS_MERCHANT_MERCHANTCODE",$fuc);
		$miObj -> setParameter("DS_MERCHANT_CURRENCY",$moneda);
		$miObj -> setParameter("DS_MERCHANT_TRANSACTIONTYPE",$trans);
		$miObj -> setParameter("DS_MERCHANT_TERMINAL",$terminal);
		$miObj -> setParameter("DS_MERCHANT_MERCHANTURL",$url);
		$miObj -> setParameter("DS_MERCHANT_URLOK",$urlOK);
		$miObj -> setParameter("DS_MERCHANT_URLKO",$urlKO);

		//Datos de configuración
		$version = "HMAC_SHA256_V1";
		$kc = 'sq7HjrUOBfKmC576ILgskD5srU870gJ7';//Clave recuperada de CANALES
		// Se generan los parámetros de la petición
		$request = "";
		$params = $miObj -> createMerchantParameters();
		$signature = $miObj -> createMerchantSignature($kc);
	}

?>

<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Cargar Saldo</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input{text-align: center;}
			select{text-align: center;}
			body {margin-top: 5%; background: linear-gradient(rgba(22,22,22,0.989), rgba(22,22,22,0.95), rgba(22,22,22,0.989)), fixed; background-size: cover; font-family: Sans-Serif;}
			.center {display: block; margin-left: auto; margin-right: auto; margin-top: 3%; margin-bottom: 3%; width: 40%;}
			tr td {text-align: center; margin:1%; padding:1%;}
			.tituloTabla {background-color: #1ed760; color: black;}
			.contenidoTabla {background-color: white; color: black;}
			.mensaje {border: 1px solid black; border-radius: 5px; padding: 10px; color: black; background-color: red;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div style="max-width: 60rem; background-color: rgba(0,0,0,0.001);">
				<header>
					<img src="https://cdn2.downdetector.com/static/uploads/logo/Spotify_Logo_RGB_Green.png" alt="Spotify" class="center">
				</header>
				<div class="card-body">
					<?php
						$invoiceId = maxInvoiceId($conexion);
						echo "<h1 style='color: white;'>Factura Nº". $invoiceId . " - Importe Total: " . $_SESSION["amount"] . " €</h1><br>";
					?>
					<form name="frm" action="https://sis-t.redsys.es:25443/sis/realizarPago" method="POST" target="_self">
						<input type="text" hidden name="Ds_SignatureVersion" value="<?php echo $version; ?>"/>
						<input type="text" hidden name="Ds_MerchantParameters" value="<?php echo $params; ?>"/>
						<input type="text" hidden name="Ds_Signature" value="<?php echo $signature; ?>"/>
						<?php mostrarCanciones($_SESSION["cancionesAgregadas"]); ?>
						<br>
						<input type="submit" value="Continuar Operación" class="btn" style="background-color: #1ed760;">
						<input type="button" value="Cancelar Operación" onclick="window.location.href='../Descargar_Canciones_Controller.php'" class="btn" style="background-color: #1ed760;">
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
