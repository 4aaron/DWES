<?php

	session_start();
	require_once "../Models/Database_Model.php";
	require_once "../Models/Historial_Facturas_Model.php";
	$conexion = conexion();

	if (empty($_SESSION["customerId"])) { // Verificamos que el usuario ha iniciado sesión
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Historial_Facturas_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$customerId = $_SESSION["customerId"];
			if (empty($_POST["fecha1"]) || empty($_POST["fecha2"])) { // Si alguna de las fechas no se ha rellenado
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Debe rellenar ambas fechas</span></div>";
			} else if ($_POST["fecha1"] > $_POST["fecha2"]) { // Si la fecha de inicio es posterior a la de fin
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>La fecha de inicio debe ser anterior a la final</span></div>";
			} else {
				$datos = lineasFacturas($conexion, $customerId, $_POST["fecha1"], $_POST["fecha2"]);
				if (empty($datos)) { // Si las fechas son correctas pero no hay facturas disponibles
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No hay facturas disponibles entre esas fechas</span></div>";
				} else {
					tablaFacturas($conexion, $datos);
				}
			}
		}
	}

?>
