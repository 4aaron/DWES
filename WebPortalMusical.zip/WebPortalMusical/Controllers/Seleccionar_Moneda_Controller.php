<?php

	session_start();
	require_once "../Models/Database_Model.php";
	require_once "../Models/Descargar_Canciones_Model.php";
	$conexion = conexion();

	if (empty($_SESSION["customerId"])) { // Verificamos que el usuario ha iniciado sesión
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Seleccionar_Moneda_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {	
			$customerId = $_SESSION["customerId"];
				if (isset($_POST["moneda"])) { // Si se ha seleccionado una moneda
					$_SESSION["moneda"] = $_POST["moneda"];
					if ($_SESSION["moneda"] == 978) { // Si se seleccionó el euro se mantiene el total
						$_SESSION["amount"] = $_SESSION["amount"];
						$_SESSION["amount2"] = 0;
					} else if ($_SESSION["moneda"] == 840) { // Si se seleccionó el dolar se calcula el 95% del total
						$_SESSION["amount2"] = $_SESSION["amount"] * 95 / 100;
					} else if ($_SESSION["moneda"] == 392) { // Si se seleccionó el yen se calcula el 90% del total
						$_SESSION["amount2"] = $_SESSION["amount"] * 90 / 100;
					}
					header("Location: ./redsysHMAC256_API_PHP_7.0.0/ejemploGeneraPet.php");
				} else { // Si no se ha seleccionado una moneda
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ninguna moneda</span></div>";
				}
			
		}
	}

?>
