<?php

	require_once "./Models/Database_Model.php";
	require_once "./Models/Login_Model.php";
	require_once "./Views/Login_View.php";

	if ($_POST) {
		$conexion = conexion();
		if (empty($_POST["email"]) || empty($_POST["password"])) { // Si el campo usuario o contraseña están en blanco se muestra un error
			echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario y contraseña deden ser rellenados</span></div>";
			
			} else if (loginUsuario($conexion, $_POST["email"], $_POST["password"])) { // Si se rellenaron los campos correctamente creamos la sesión y redirigimos al controlador
				session_start();
				$_SESSION["email"] = $_POST["email"];
				$datosUsuario = datosUsuario($conexion, $_SESSION["email"]); // Obtenemos los datos del usuario
				$_SESSION["customerId"] = $datosUsuario[0];
				$_SESSION["firstName"] = $datosUsuario[1];
				$_SESSION["lastName"] = $datosUsuario[2];
				$_SESSION["company"] = $datosUsuario[3];
				$_SESSION["address"] = $datosUsuario[4];
				$_SESSION["city"] = $datosUsuario[5];
				$_SESSION["state"] = $datosUsuario[6];
				$_SESSION["country"] = $datosUsuario[7];
				$_SESSION["postalCode"] = $datosUsuario[8];
				$_SESSION["phone"] = $datosUsuario[9];
				$_SESSION["fax"] = $datosUsuario[10];
				$_SESSION["email"] = $datosUsuario[11];
				header("Location: ./Views/Welcome_View.php");
				
				} else { // Si ambos campos han sido rellenados pero son incorrectos se muestra un error
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>El usuario o contraseña introducidos son incorrectos</span></div>";
		}
	}

?>
