<?php

	session_start();
	require_once "../Models/Database_Model.php";
	require_once "../Models/Descargar_Canciones_Model.php";
	$conexion = conexion();

	if (empty($_SESSION["customerId"])) { // Verificamos que el usuario ha iniciado sesión
		header("Location: ../Index.php");
	} else {
		require_once "../Views/Descargar_Canciones_View.php";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {	
			$cancionSeleccionada = "";
			$customerId = $_SESSION["customerId"];

			if (isset($_POST["Agregar"])) { // Si se pulsa el botón de agregar
				if (empty($_POST["cancion"])) {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>No ha seleccionado ninguna canción</span></div>";
				} else {
					$cancionSeleccionada = $_POST["cancion"];
					if (!isset($_SESSION["cancionesAgregadas"])) { // Si no hay canciones añadidas previamente
						$_SESSION["idCancionesAgregadas"] = array($cancionSeleccionada);
						$datosCancion = datosCancion($conexion, $cancionSeleccionada);
						$_SESSION["cancionesAgregadas"] = array($datosCancion);
						mostrarCanciones($_SESSION["cancionesAgregadas"]);
						$_SESSION["quantity"] = 1;
						$_SESSION["unitPrice"] = $datosCancion[1];
						$_SESSION["amount"] = $datosCancion[1];
					} else { // Si ya hay canciones añadidas
						array_push($_SESSION["idCancionesAgregadas"], $cancionSeleccionada);
						$datosCancion = datosCancion($conexion, $cancionSeleccionada);
						array_push($_SESSION["cancionesAgregadas"], $datosCancion);
						mostrarCanciones($_SESSION["cancionesAgregadas"]);
						$_SESSION["amount"] = $_SESSION["amount"] + $datosCancion[1];
					}
				}
			}

			if (isset($_POST["Descargar"])) { // Si se pulsa el botón de descargar
				if (empty($_SESSION["cancionesAgregadas"])) {
					echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Es necesario agregar canciones antes de descargarlas</span></div>";
				} else {
					header("Location: ./Seleccionar_Moneda_Controller.php");
				}
			}
			if (isset($_POST["Borrar"])) { // Si se pulsa el botón de borrar
				unset($_SESSION["cancionesAgregadas"]);
				unset($_SESSION["idCancionesAgregadas"]);
				unset($_SESSION["amount"]);
				unset($_SESSION["quantity"]);
				unset($_SESSION["moneda"]);
				echo "<br><div class='h5' style='text-align: center;'><span class='mensaje'>Las canciones se eliminaron correctamente</span></div>";
			}
			
		}
	}

?>
