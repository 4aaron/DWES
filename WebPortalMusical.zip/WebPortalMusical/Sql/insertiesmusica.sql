ALTER TABLE invoice ADD Total2 decimal(10,2) NOT NULL;
ALTER TABLE invoice ADD Moneda INT NOT NULL;

