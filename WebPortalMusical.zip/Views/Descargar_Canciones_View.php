<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Descargar Canciones Portal Musical</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input{text-align: center;}
			select{text-align: center;}
			body {margin-top: 5%; background: linear-gradient(rgba(22,22,22,0.989), rgba(22,22,22,0.95), rgba(22,22,22,0.989)), fixed; background-size: cover; font-family: Sans-Serif;}
			.center {display: block; margin-left: auto; margin-right: auto; margin-top: 3%; margin-bottom: 3%; width: 40%;}
			tr td {text-align: center; margin:1%; padding:1%;}
			.tituloTabla {background-color: #1ed760; color: black;}
			.contenidoTabla {background-color: white; color: black;}
			.mensaje {border: 1px solid black; border-radius: 5px; padding: 10px; color: black; background-color: red;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div style="max-width: 60rem; background-color: rgba(0,0,0,0.001);">
				<header>
					<img src="https://cdn2.downdetector.com/static/uploads/logo/Spotify_Logo_RGB_Green.png" alt="Spotify" class="center">
				</header>
				<div class="card-body">
					<h1 style="color: white;">Descargar Canciones</h1>
					<br>
					<?php # Datos del usuario
						echo "<h4 style='color: white;'>" . $_SESSION["firstName"] . " " .  $_SESSION["lastName"] . "<br>" . $_SESSION["company"] . "</h4>";
					?>
					<form method="POST">
						<br>
						<h4 style="color: white;"><?php desplegableCanciones(); ?></h4>
						<br>
						<input type="submit" name="Agregar" value="Agregar" class="btn" style="background-color: #1ed760;">
						<input type="submit" name="Descargar" value="Descargar" class="btn" style="background-color: #1ed760;">
						<input type="submit" name="Borrar" value="Borrar" class="btn" style="background-color: #1ed760;">
						<input type="button" value="Volver" onclick="window.location.href='../Views/Welcome_View.php'" class="btn" style="background-color: #1ed760;">
						<br><br>
						<a href="../Controllers/Cerrar_Sesion_Controller.php">Cerrar Sesión</a>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
