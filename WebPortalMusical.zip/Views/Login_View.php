<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Inicio de sesión Portal Musical</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input{text-align: center;}
			body {margin-top: 5%; background: linear-gradient(rgba(22,22,22,0.989), rgba(22,22,22,0.95), rgba(22,22,22,0.989)), fixed; background-size: cover; font-family: Sans-Serif;}
			.center {display: block; margin-left: auto; margin-right: auto; margin-top: 3%; margin-bottom: 3%; width: 40%;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div style="max-width: 60rem; background-color: rgba(0,0,0,0.001);">
				<header>
					<img src="https://cdn2.downdetector.com/static/uploads/logo/Spotify_Logo_RGB_Green.png" alt="Spotify" class="center">
				</header>
				<div class="card-body">
					<h1 style="color: white;">Iniciar Sesión</h1>
					<br>
					<form method="post">
						<div class="form-group">
							<input type="text" name="email" class="form-control form-control-lg" placeholder="Usuario (Correo)" autofocus>
						</div>
						<br>
						<div class="form-group">
							<input type="password" name="password" class="form-control form-control-lg" placeholder="Contraseña (Apellido)">
						</div>
						<br>
						<input type="submit" value="Iniciar Sesión" class="btn" style="background-color: #1ed760;">
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
