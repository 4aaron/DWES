<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Inicio de sesión Portal Musical</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<style>
			input{text-align: center;}
			body {margin-top: 5%; background: linear-gradient(rgba(22,22,22,0.989), rgba(22,22,22,0.95), rgba(22,22,22,0.989)), fixed; background-size: cover; font-family: Sans-Serif;}
			.center {display: block; margin-left: auto; margin-right: auto; margin-top: 3%; margin-bottom: 3%; width: 40%;}
		</style>
	</head>
	<body>
		<div class="container" align="center">
			<div style="max-width: 60rem; background-color: rgba(0,0,0,0.001);">
				<header>
					<img src="https://cdn2.downdetector.com/static/uploads/logo/Spotify_Logo_RGB_Green.png" alt="Spotify" class="center">
				</header>
				<div class="card-body">
					<h1 style="color: white;">¡Bienvenido al portal musical!</h1>
					<br>
					<?php # Datos del usuario
						session_start();
						echo "<h4 style='color: white;'>" . $_SESSION["firstName"] . " " .  $_SESSION["lastName"] . "<br>" . $_SESSION["company"] . "</h4>";
					?>
					<form method="POST">
						<br>
						<input type="button" value="Descargar Canciones" onclick="window.location.href='../Controllers/Descargar_Canciones_Controller.php'" class="btn" style="background-color: #1ed760;">
						<input type="button" value="Historial Facturas" onclick="window.location.href='../Controllers/Historial_Facturas_Controller.php'" class="btn" style="background-color: #1ed760;">
						<input type="button" value="Consultar Facturas" onclick="window.location.href='../Controllers/Consultar_Facturas_Controller.php'" class="btn" style="background-color: #1ed760;">
						<br><br>
						<a href="../Controllers/Cerrar_Sesion_Controller.php">Cerrar Sesión</a>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
